Funziona con FF ed IE. Chrome va avviato con questo parametro
--allow-file-access-from-files
 per dargli l'autorizzazione a leggere file locali.