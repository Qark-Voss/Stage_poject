package com.zucchetti.sitepainter.Analyzer.Model;

public interface ExplFactoryInterface {
	public ExplainInterface getExplainer(int DB);
}