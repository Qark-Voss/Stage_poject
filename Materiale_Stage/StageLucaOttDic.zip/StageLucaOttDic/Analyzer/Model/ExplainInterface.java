package com.zucchetti.sitepainter.Analyzer.Model;

public interface ExplainInterface {
	public InterfaceNodo explainQuery(String query, String contextID);
}
