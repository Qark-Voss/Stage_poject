package com.zucchetti.sitepainter.Analyzer.Controller;

public interface EvalFactoryInterface {
	public EvaluationAbstract getEvaluation(int DB);
}