/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global error, SlideListManager, ERR, initManager, MEX, MS */

/**********Info******************************************
 * File: controller.js
 * Versione: 1.0
 * Data creazione: 09/02/2011
 * Data ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * E-mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Riccardo Cucco} correzione degli errori rilevati con JsLint
 * versione: 0.9 25/02/2011 {Riccardo Cucco} modificato metodo moveBranch()
 * versione: 0.8 24/02/2011 {Riccardo Cucco} aggiunta dei metodi isParentOf() e isPreviousOf()
 * versione: 0.7 22/02/2011 {Riccardo Cucco} ottimizzazione del metodo deleteSlide()
 * versione: 0.6 17/02/2011 {Riccardo Cucco} aggiunta dei metodi getContent(), setContent(), getTitle(), getFooter(), getParent(), setParent(), getChild() e getElements(), setSlideContent()
 * versione: 0.5 16/02/2011 {Riccardo Cucco} aggiunta dei metodi moveBranchAsSibling(), moveBranchAsSlide(),  moveSlideAsSibling(), moveSlidedAsChild()
 * versione: 0.4 14/02/2011 {Riccardo Cucco} aggiunta dei metodi addChild(), addSibling(), addSlide(), addSlideList(), pushElement(),  correzione degli errori rilevati con jslint
 * versione: 0.3 12/02/2011 {Riccardo Cucco} aggiunta dei metodi deleteSlide(), saveMenuInfo(), loadMenuInfo(), slideTitle(), getProjectList(), deleteSlideList()
 * versione: 0.2 11/02/2011 {Riccardo Cucco} aggiunta dei metodi popElement(), pushChild() e popChild()
 * versione: 0.1 09/02/2011 {Riccardo Cucco} creazione classe, aggiunta dei metodi createSlide(), createContent(), createSlideList, createProject(), createUser(), addProject(), getProjectList(), loadProject(), sendNotification(), askQuestion(), newUser(), newProject(), loadProject()
 *
 * ********Licenza********************************************
 *
 *This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *
 * ********Scopo*****************************************
 * L'oggetto ControllerDispatcher racchiude al suo interno tutti
 * i manager necessari a modificare lo stato del model.
 * Questi manager sono stati realizzati mediante object-literals
 * dal funzionamento analogo agli oggetti di tipo singleton.
 *
 */

function ControllerDispatcher(ModelHandler) {
    /**
     * permette di accedere alle funzionalità della classe
     * ModelHandler
     */
    var Model = ModelHandler,
    /**
     * L'oggetto Singleton Builder racchiude all'interno
     * le primitive per la creazione di oggetti-stato
     * @class Builder
     */
    Builder = {
        /**
         * Il metodo createSlide(slide_id,parent_id) restituisce un oggetto Slide inizializzato
         * con il parametro id e con il riferimento alla slideList padre
         * @return Slide object
         * @param {slide_id} chiave della slide nell'array associativo
         * @param {parent_id} chiave della slideList nell'array associativo
         */
        createSlide: function (slide_id, parent_id) {
            return { id : slide_id,
                title : "slide #" + slide_id,
                footer : "std_footer",
                content : null,
                child : [],
                parent : parent_id };
        },
        /**
         * Il metodo createContent(content_id,slide_id,content)
         * crea un nuovo oggetto contenuto a cui vengono assegnati
         * i valori passati come parametri. In particolare mantiene
         * un identificatore, un corpo e un riferimento al padre.
         * @return Content object
         * @param {content_id} chiave dell'oggetto Content
         * @param {slide_id} chiave della slide che contiene il contenuto con chiave content_id
         * @param {content} corpo del contenuto
         *
         */
        createContent: function (content_id, slide_id, content) {
            return { id : content_id,
                body : content,
                parent : slide_id };
        },
        /**
         * il metodo createSlideList(list_id,parent_id)
         * restituisce un oggetto SlideList inizializzato
         * con il parametro id e con il riferimento alla slide padre
         * @return SlideList object
         * @param {list_id} chiave della SlideList nell'array associativo
         * @param {parent_id} chiave della slide padre nell'array associativo
         */
        createSlideList: function (list_id, parent_id) {
            return {	id : list_id,
                parent : parent_id,
                elements : []
            };
        },
        /**
         * Il metodo createProject(project_id) calcola la data e l'ora attuali
         * e le assegna ad un oggetto Project il cui identificatore viene inizializzato
         * con il parametro project_id. L'oggetto contiene le informazioni relative ad
         * un singolo progetto e viene infine ritornato dal metodo stesso.
         * @return Project object
         * @param {project_id} chiave del progetto nell'array associativo
         */
        createProject: function (project_id) {
            var date = new Date(),
            today = (date.getDate() < 10 ? "0" : "") + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? "0" : "") + (date.getMonth() + 1) + "/" + date.getFullYear(),
            project = { id : project_id,
                title : "Progetto senza titolo #" + project_id + " [click to modify]",
                description : "Progetto vuoto [click to modify]",
                event_description : "descrizione evento [click to modify]",
                event_date : today,
                location : "location evento [click to modify]",
                creation_date : today,
                last_update : today
            };
            return project;
        },
        /**
         * Il metodo createUser() restituisce un oggetto User. L'oggetto contiene
         * le informazioni relative all'utente e ai suoi progetti
         * @return User object
         */
        createUser: function () {
            return { username : "username", /*TODO controllare se da togliere*/
                password : "password", /*TODO controllare se da togliere*/
                name : "nome utente",
                surname : "cognome utente",
                projects : {
                    next_id : 0
                }
            };
        }
    },
    /**
     * L'oggetto SlideManager fornisce le funzionalità di gestione dell'array
     * associativo di oggetti di tipo Slide contenuti negli oggetti Project definiti
     * nel ModelHandler
     * @class SlideManager
     */
    SlideManager = {
        loaded: false,
        element_array: null,
        /**
         * Il metodo init(slide_array) inizializza l'array associativo che contiene
         * le slide assegnandogli l'oggetto associato al parametro slide_array.
         * @param {slide_array} array associativo di slide
         */
        init: function (slide_array) {
            this.element_array = slide_array;
            this.loaded = true;
        },
        /**
         * Il metodo addSlide(parent_id,index) aggiunge una nuova slide alla struttura.
         * In particolare controlla che l'array associativo
         * contenente le slide sia stato inizializzato. In caso positivo viene
         * creata una nuova slide nella prima posizione libera dell'array associativo.
         * Viene restituito l'id della nuova slide. In caso negativo viene restituito -1.
         * @return int
         * @param {parent_id} id della SlideList in cui inserire la slide
         * @param {index} posizione dell'array associativo in cui aggiungere la slide
         */
        addSlide: function (parent_id, index) {
            if (this.loaded) {
                var id = this.element_array.next_id;
                this.element_array.next_id += 1;
                this.element_array[id] = Builder.createSlide(id, parent_id);
                SlideListManager.pushElement(parent_id, id, index);
                //console.info("Created slide #" + id + ", son " + (index !== undefined ? "#" + index + " ":"") + "of slideList #" + parent_id);
                this.element_array.modified = true;
                return id;
            } else {
                error(ERR.SM_not_load);
                return -1;
            }
        },
        /**
         * Il metodo pushChild(slide_id,slideList_id) aggiunge all'array di figli di una slide
         * la chiave di una SlideList figlia. Per ottenere questo comportamento viene recuperata
         * la slide di chiave slide_id dall'array associativo ed ottenuto il suo array di figli.
         * A questo array viene aggiunta la chiave slideList_id
         * @param {slide_id} chiave della slide a cui aggiungere un figlio
         * @param {slideList_id} chiave della nuova SlideList figlia
         */
        pushChild: function (slide_id, slideList_id) {
            this.element_array[slide_id].child.push(slideList_id);
            this.element_array.modified = true;
        },
        //TODO: verificare che quando viene spostato l'ultimo elemento di una slideList essa venga distrutta!//FIXME
        /**
         * Il metodo popChild(slide_id,slideList_id) toglie dall'array di figli di una slide
         * la chiave di una slideList figlia. Per ottenere questo comportamento viene recuperata
         * la slide di chiave slide_id dall'array associativo ed ottenuta la posizione della sua SlideList
         * figlia con chiave slideList_id nell'array che contiene le sue SlideList figlie.
         * Se tale posizione esiste viene tolta dall'array la chiave
         * in essa contenuta, altrimenti viene lanciato un errore.
         * @param {slide_id} chiave della slide a cui togliere un figlio
         * @param {slideList_id} chiave della slideList figlia da togliere
         */
        popChild: function (slide_id, slideList_id) {
            var pop_index = this.element_array[slide_id].child.indexOf(slideList_id);
            if (pop_index >= 0) {
                this.element_array[slide_id].child.splice(pop_index, 1);
                this.element_array.modified = true;
            } else {
                error(ERR.base);
            }
        },
        /**
         * Il metodo deleteSlide(slide_id) cancella la slide con chiave slide_id
         * e tutte le SlideList figlie. In particolare controlla che l'array associativo
         * contenente le slide sia stato inizializzato. In caso positivo
         * controlla che la slide che si trova in posizione slide_id
         * dell'array associativo sia definita. Se è definita richiama il metodo
         * deleteSlideList(slideList_id) della classe SlideListManager per rimuovere
         * le slide contenute nelle SlideList figlie della slide con chiave slide_id
         * e richiama il metodo popElement(slideList_id,slide_id) della classe
         * SlideListManager per cancellare le SlideList figlie. Viene infine cancellata
         * dall'array associativo la slide con chiave slide_id.
         *@param {slide_id} chiave della slide da rimuovere
         */
        deleteSlide: function (slide_id) {
            if (this.loaded) {
                if (this.element_array[slide_id] !== undefined) {
                    var i;
                    for (i = 0; i < this.element_array[slide_id].child.length; i += 1) {
                        SlideListManager.deleteSlideList(this.element_array[slide_id].child[i]);
                    }
                    SlideListManager.popElement(SlideManager.getParent(slide_id), slide_id);
                    delete this.element_array[slide_id];
                    this.element_array.modified = true;
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
        },
        /**
         * Il metodo getTitle(slide_id) restituisce il titolo della slide con chiave
         * slide_id. In particolare controlla che l'array associativo
         * contenente le slide sia stato inizializzato. In caso positivo
         * controlla che la slide che si trova in posizione slide_id
         * dell'array associativo sia definita. Se è definita ritorna il
         * titolo della slide con chiave slide_id dell'array associativo.
         * In tutti gli altri casi viene lanciato un errore.
         * @return String
         * @param {slide_id} chiave della slide di cui restituire il titolo
         */
        getTitle: function (slide_id) {
            if (this.loaded) {
                if (this.element_array[slide_id] !== undefined) {
                    return this.element_array[slide_id].title;
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
        },
        /**
         * Il metodo getFooter(slide_id) restituisce il footer della slide con chiave
         * slide_id. In particolare controlla che l'array associativo
         * contenente le slide sia stato inizializzato. In caso positivo
         * controlla che la slide che si trova in posizione slide_id
         * dell'array associativo sia definita. Se è definita ritorna il footer
         * della slide. In tutti gli altri casi lancia un errore.
         * @return String
         * @param {slide_id} chiave della slide di cui restituire il footer
         */
        getFooter: function (slide_id) {
            if (this.loaded) {
                if (this.element_array[slide_id] !== undefined) {
                    return this.element_array[slide_id].footer;
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
        },
        /**
         * Il metodo getParent(slide_id) restituisce la chiave della SlideList
         * a cui appartiene la slide con chiave slide_id. Controlla che l'array associativo
         * contenente le slide sia stato inizializzato. In caso negativo
         * viene lanciato un errore. In caso positivo
         * controlla che la slide che si trova in posizione slide_id
         * dell'array associativo sia definita. In caso positivo restituisce
         * la chiave della SlideList di appartenenza della slide. In caso negativo viene
         * lanciato un errore.
         * @return
         * @param {slide_id} chiave della slide di cui restituire il riferimento
         * alla SlideList di appartenenza
         */
        getParent: function (slide_id) {
            if (this.loaded) {
                if (this.element_array[slide_id] !== undefined) {
                    return this.element_array[slide_id].parent;
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
        },
        /**
         * Il metodo setParent(slide_id,parent_id) controlla che
         * l'array associativo contenente le slide sia stato inizializzato.
         * In caso negativo viene lanciato un errore.
         * In caso positivo controlla che la slide che si trova in posizione slide_id
         * dell'array associativo sia definita. In caso positivo
         * viene assegnato al riferimento al padre della slide
         * il valore associato al parent_id. In caso negativo viene lanciato
         * un errore.
         */
        setParent: function (slide_id, parent_id) {
            if (this.loaded) {
                if (this.element_array[slide_id] !== undefined) {
                    this.element_array[slide_id].parent = parent_id;
                    this.element_array.modified = true;
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
        },
        /**
         * Il metodo getChild(slide_id) restituisce le SlideList figlie di una slide.
         * Per fare ciò controlla che
         * l'array associativo contenente le slide sia stato inizializzato.
         * In caso negativo viene lanciato un errore. In caso positivo
         * controlla che la slide con chiave slide_id
         * dell'array associativo sia definita. In caso affermativo restituisce
         * una copia dell'array dei figli della slide. Altrimenti viene
         * lanciato un errore.
         * @return SlideList array
         * @param {slide_id} chiave della slide di cui restituire le SlideList figlie
         */
        getChild: function (slide_id) {
            if (this.loaded) {
                if (this.element_array[slide_id] !== undefined) {
                    return this.element_array[slide_id].child.slice(0);
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
        },
        /**
         * Il metodo getContent(slide_id) restituisce il corpo del contenuto di una slide.
         * Per fare ciò controlla che l'array associativo
         * contenente le slide sia stato inizializzato. In caso positivo controlla che
         * la slide con chiave slide_id dell'array associativo sia definita.
         * Se non è definita viene lanciato un erorre, altrimenti
         * controlla che il contenuto della slide non sia nullo. Se non
         * è nullo viene ritornato il corpo del contenuto della slide. In tutti gli
         * altri casi viene ritornato il valore false.
         * @return Boolean o String
         * @param {slide_id} chiave della slide di cui restituire il corpo
         */
        getContent: function (slide_id) {
            if (this.loaded) {
                if (this.element_array[slide_id] !== undefined) {
                    if (this.element_array[slide_id].content !== null && this.element_array[slide_id].content !== "null" ) {
                        return Model.project.content[this.element_array[slide_id].content].body;
                    } else {
                        return false;
                    }
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
            return false;
        },
        /**
         * Il metodo setContent(slide_id,content) permette di impostare il
         * corpo del contenuto di una slide. Per fare ciò controlla che l'array
         * associativo contenente le slide sia stato inizializzato. In caso positivo
         * controlla che la slide con chiave slide_id dell'array
         * associativo sia definita. Se è definita controlla se il
         * contenuto della slide è nullo. Se non è nullo viene assegnato al
         * campo dell'array del progetto che contiene i contenuti delle slide
         * il valore del parametro content. Altrimenti viene creato un nuovo oggetto Content, che viene
         * assegnato all'oggetto corrispondente alla chiave id dell'array content contenuto nella
         * slide, e viene ritornato il suo id. In tutti gli altri casi viene
         * ritornato il valore false.
         * @return Int o Boolean
         * @param {slide_id} chiave della slide di cui settare il corpo del contenuto
         * @content {content} stringa che contiene il nuovo contenuto della slide
         */
        setContent: function (slide_id, content) {
            if (this.loaded) {
                if (this.element_array[slide_id] !== undefined) {
                    if (this.element_array[slide_id].content !== null && this.element_array[slide_id].content !== "null") {
                        Model.project.content[this.element_array[slide_id].content].body = content;
                    } else {
                        var id = Model.project.content.next_id;
                        Model.project.content.next_id += 1;
                        Model.project.content[id] = Builder.createContent(id, slide_id, content);
                        this.element_array[slide_id].content = id;
                        this.element_array.modified = true;
                        return id;
                    }
                    Model.project.content.modified = true;
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
            return false;
        }
    },
    /**
     * L'oggetto SlideListManager fornisce le funzionalità di gestione dell'array
     * associativo di oggetti di tipo SlideSlist contenuti negli oggetti Project definiti
     * nel ModelHandler
     * @class SlideListManager
     */
    SlideListManager = {
        loaded : false,
        element_array : null,
        /**
         * Il metodo init(SlideList_array) inizializza l'array associativo
         * contenente le SlideList assegnandogli l'oggetto associato al parametro
         * SlideList_array.
         * @param {SlideList_array} array di SlideList con cui inizializzare l'array associativo
         */
        init : function (SlideList_array) {
            this.element_array = SlideList_array;
            this.loaded = true;
        },
        /**
         * Il metodo addSlideList(parent_id,content_slide) aggiunge una nuova
         * SlideList alla struttura. In particolare controlla che l'array associativo
         * contenente le SlideList sia stato inizializzato. In caso negativo viene lanciato
         * un errore. In caso positivo
         * viene creata una nuova SlideList nella prima posizione libera dell'array
         * associativo. Viene poi controllato il valore del parametro content_slide.
         * Se è nullo o non definito viene richiamato il metodo
         * addSlide(parent_id,index) della classe SlideManager per aggiungere
         * una nuova slide alla SlideList. Altrimenti viene assegnato al
         * riferimento al padre nell'array di interi che identificano le slide
         * contenute nella SlideList l'id della nuova SlideList. Viene infine ritornato
         * l'identificatore della nuova slideList
         * @return Int
         * @param {parent_id} chiave della slide padre della nuova SlideList
         * @param {content_slide} array che contiene i contenuti delle nuove slide
         * della SlideList
         */
        addSlideList: function (parent_id, content_slide) {
            if (this.loaded) {
                var element_id = this.element_array.next_id,
                element = Builder.createSlideList(element_id, parent_id),
                i;
                this.element_array.next_id += 1;
                this.element_array[element_id] = element;
                this.element_array.modified = true;
                if (content_slide === undefined || content_slide === null) {
                    SlideManager.addSlide(element_id);
                } else {
                    //conten slide può essere un array o un valore singolo
                    if (content_slide.length !== undefined) {
                        element.elements = content_slide;
                        for (i = 0; i < content_slide.length; i += 1) {
                            SlideManager.setParent(content_slide[i], element_id);
                        }
                    } else {
                        element.elements.push(content_slide);
                        SlideManager.setParent(content_slide, element_id);
                    }
                }

                this.element_array.modified = true;
                return element_id;
            } else {
                error(ERR.SLM_not_load);
            }

        },
        /*TODO inserire la spiegazione nella definizione di prodotto*/
        /**
         * Il metodo pushElement(slideList_id,slide_id,index) aggiunge un elemento all'array associativo.
         * In particolare controlla se il valore associato al parametro index è indefinito o nullo.
         * In questo caso viene aggiunta alla fine della SlideList con chiave slideList_id
         * nell'array associativo una nuova slide con identificatore slide_id. In caso contrario viene
         * ritornata la slide che si trova nella posizione index dell'array associativo
         * e viene aggiunta all'array la slide con identificatore slide_id.
         * @return Slide
         * @param {slideList_id} chiave della SlideList a cui aggiungere la slide
         * @param {slide_id} chiave della slide da aggiungere alla slideList
         * @param {index} posizione dell'array associativo da cui togliere la slide
         */
        pushElement : function (slideList_id, slide_id, index) {
            if (index === undefined || index === null) {
                this.element_array[slideList_id].elements.push(slide_id);
            } else {
                this.element_array[slideList_id].elements.splice(index, 0, slide_id);
            }
            this.element_array.modified = true;
        },
        /**
         * Il metodo popElment(slideList_id,slide_id)
         * toglie un elemento dall'array associativo. In particolare
         * viene recuperata la SlideList di chiave slideList_id ed ottenuta
         * la posizione della slide con chiave slide_id nell'array che contiene le
         * slide della SlideList in questione. Se tale posizione esiste viene tolta
         * dall'array la chiave in essa contenuta e viene controllata la lunghezza della
         * SlideList. Se è 0 viene richiamata la funzione popChild(slide_id,SlideList_id)
         * della classe SlideManager per togliere dall'array la chiave slideList_id
         * della SlideList. Viene poi cancellata la SlideList dall'array associativo.
         * In tutti gli altri casi viene lanciato un errore.
         * @param {slideList_id} chiave della SlideList da togliere dall'array associativo
         * @param {slide_id} chiave della slide da togliere dall'array contenente le slide della SlideList
         */
        popElement: function (slideList_id, slide_id) {
            var pop_index = this.element_array[slideList_id].elements.indexOf(slide_id);
            if (pop_index >= 0) {
                this.element_array[slideList_id].elements.splice(pop_index, 1);
                if (this.element_array[slideList_id].elements.length === 0) {
                    SlideManager.popChild(this.element_array[slideList_id].parent, slideList_id);
                    delete this.element_array[slideList_id];
                }
                this.element_array.modified = true;
            } else {
                error(ERR.base);
            }
        },
        /**
         * Il metodo getElements(slideList_id) restituisce una copia dell'array
         * di slide della SlideList con chiave slideList_id.
         * @return Slide array
         * @param {slideList_id} chiave della SlideList di cui restituire le slide
         */
        getElements: function (slideList_id) {
            //ritorna una copia dell'array
            return this.element_array[slideList_id].elements.slice(0);
        },
        /**
         * Il metodo deleteSlideList(slideList_id) rimuove una SlideList dalla
         * struttura. In particolare controlla che l'array associativo
         * contenente le slideList sia stato inizializzato. In caso positivo
         * controlla che la SlideList con chiave slideList_id
         * dell'array associativo sia definita. Se è definita richiama il metodo
         * deleteSlide(slide_id) della classe SlideManager
         * per cancellare le slide della SlideList con chiave
         * slideList_id e le loro SlideList figlie. In tutti gli altri casi viene
         * lanciato un errore.
         * @param {slideList_id} chiave della SlideList da rimuovere
         */
        deleteSlideList: function (slideList_id) {
            if (this.loaded) {
                if (this.element_array[slideList_id] !== undefined) {
                    //l'eliminazione dell'ultimo child con popChild cancellerà la slideList
                    //ed informerà la slide padre dell'eliminazione della slidelist
                    for (var j = 0, max = this.element_array[slideList_id].elements.length; j < max; j += 1) {
                        SlideManager.deleteSlide(this.element_array[slideList_id].elements[j]);
                    }
                    this.element_array.modified = true;
                } else {
                    error(ERR.Slide_not_found);
                }
            } else {
                error(ERR.SM_not_load);
            }
        }
    },
    /**
     * L'oggetto ProjectManager fornisce le funzionalità necessarie all'utente
     * per la creazione di un nuovo progetto o il caricamento di un progetto precedente.
     * In particolare gestisce l'array di oggetti di tipo Project.
     * @class ProjectManager
     */
    ProjectManager = {
        /**
         * Il metodo addProject() permette di aggiungere
         * un nuovo progetto all'array che contiene i progetti dell'utente.
         * In particolare recupera tale array, vi aggiunge un nuovo progetto nella prima posizione libera e
         * ne recupera l'indice. A questo punto notifica al Model la creazione di un
         * nuovo progetto di indice k richiamando la funzione newProject(key)
         * della classe ModelHandler. Infine richiama il metodo addSlideList(parent_id,content_slide)
         * della classe SlideListManager per aggiungere una nuova SlideList al progetto e viene
         * ritornato l'id del nuovo progetto.
         * @return Int
         */
        addProject: function () {
            var project_list = Model.user.projects,
            project_id = project_list.next_id;
            project_list.next_id += 1;
            project_list[project_id] = Builder.createProject(project_id);
            Model.newProject(project_id);
            initManager(); //TODO:controllare che initManager sia visibile da questo punto
            SlideListManager.addSlideList();
            return project_id;
        },
        deleteProject: function (id) {
            Model.deleteProject(id);
        },
        /**
         * Il metodo getProjectList() restituisce una copia dell'array che contiene i progetti dell'utente.
         * In particolare recupera dall'array di progetti contenuto nell'oggetto associato all'attributo
         * user del ModelHandler
         * il titolo, la descrizione dell'evento e la descrizione del progetto. Nel caso in cui
         * la copia sia avvenuta con successo essa viene restituita, altrimenti viene restituito il
         * valore false
         * @return String array o Boolean
         */
        getProjectList: function () {
            var empty = true,
            projects_list = [],
            i;
            for (i in Model.user.projects) {
                if (i >= 0) {
                    projects_list.push([i, Model.user.projects[i].title, Model.user.projects[i].event_description, Model.user.projects[i].description]);
                    empty = false;
                }
            }
            if (empty) {
                return false;
            } else {
                return projects_list;
            }
        },
        /**
         * Il metodo loadProject(key) carica il progetto con chiave key creato dall'utente.
         * In particolare controlla se il progetto con chiave key creato dall'utente
         * è definito. In caso positivo viene richiamato il metodo initManager() per
         * inizializzare gli array associativi che contengono le Slide e le SlideList
         * del progetto dell'utente. In caso negativo viene lanciato un errore.
         * @param {key} chiave del progetto da caricare
         */
        loadProject: function (key) {
            if (Model.loadProject(key)) {
                initManager();
            } else {
                error(ERR.project_not_loaded);
            }

        },
        /**
         * Il metodo getProjectDetails(id) restituisce i dettagli del progetto con chiave id.
         * In particolare recupera l'array di oggetti Project contenuto nell'oggetto di tipo User associato
         * all'attributo user del Model Handler
         * e restituisce un array contenente l'id del progetto, il suo titolo, la sua descrizione,
         * la descrizione dell'evento, la data dell'evento, il luogo dell'evento, la data dell'ultimo
         * aggiornamento e la data di creazione.
         * @return String array
         * @param {id} chiave del progetto di cui restituire i dettagli
         */
        getProjectDetails: function (id) {
            if (id === undefined) {
                id = Model.project.id;
            }
            var project_data = Model.user.projects[id];
            return [project_data.id,
            project_data.title,
            project_data.description,
            project_data.event_description,
            project_data.event_date,
            project_data.location,
            project_data.last_update,
            project_data.creation_date];
        }
    },
    /**
     * L'oggetto UserManager fornisce le funzionalità necessarie alla gestione
     * dei dati contenuti negli oggetti di tipo User.
     * @class UserManager
     */
    UserManager = {
        /**
         * Il metodo newUser() crea un nuovo utente. In particolare
         * richiama il metodo createUser() della classe Builder
         * per creare un nuovo oggetto di tipo User e lo assegna all'attributo pubblico
         * user della classe ModelHandler.
         * Richiama poi il metodo addProject()
         * della classe ProjectManager per aggiungere un nuovo progetto all'array che contiene
         * i progetti relativi all'utente associato all'attributo user del ModelHandler e
         * restituisce la chiave del progetto.
         * @return Int
         */
        newUser : function () {
            Model.user = Builder.createUser();
            var project_id = ProjectManager.addProject();
            Model.saveUser();
            return project_id;
        },
        /**
         * Il metodo getUserDetails() ritorna le informazioni relative all'utente. In particolare
         * accede al nome e al cognome dell'utente associato all'attributo user della classe Model Handler
         * e ritorna tali informazioni in un array.
         * @return String array
         */
        getUserDetails: function () {
            return [Model.user.name, Model.user.surname];
        }
    },
    /**
     * L'oggetto MessageDispatcher fornisce alla componente Controller un accesso
     * all'area di notifica dell'interfaccia utente permettendo quindi la comunicazione tra la
     * componente View e la componente Controller.
     * @class MessageDispatcher
     */
    MessageDispatcher = {
        /**
         * Il metodo sendMessage(message) inoltra alla View il messaggio message
         * @param {message} messaggio da inoltrare
         */
        sendMessage: function (message) {
            MS.View.comunication.showMessage(message);
        },
        /**
         * Il metodo sendNotification(notification) inoltra alla view la notifica
         * notification
         * @param {notification} notifica da inoltrare
         */
        sendNotification: function (notification) {
            MS.View.comunication.showNotification(notification);
        },
        /**
         * Il metodo askQuestion(question,option) inoltra alla View la domanda
         * question e le relative possibili opzioni da scegliere e ritorna l'id
         * dell'opzione scelta
         * @return Int
         * @param {question} domanda da inoltrare
         * @param {options} opzioni da scegliere
         */
        askQuestion : function (question, options) {
            MS.View.comunication.showQuestion(question, options);
        }
    },
    /**
     * Il metodo initManager() inizializza gli array associativi. In particolare
     * richiama il metodo init(slide_array) della classe SlideManager
     * per inzializzare l'array associativo contenente le Slide e il metodo
     * init(SlideList_array) della classe SlideListManager per inizializzare
     * l'array associativo contenente le SlideList.
     */
    initManager = function () {
        SlideManager.init(Model.project.slide);
        SlideListManager.init(Model.project.slideList);
    };
    /**
     * Il metodo save() richiama le funzioni saveUser() e saveProject()
     * della classe ModelHandler per memorizzare nel localStorage le informazioni
     * relative all'utente e al progetto
     */
    this.save = function () {
        Model.saveUser();
        Model.saveProject();
    };
    /**
     * Il metodo newUser() richiama la classe newUser() della classe UserManager
     * per creare un nuovo utente e richiama il metodo save per memorizzare le
     * informazioni relative all'utente appena creato e ai suoi progetti.
     */
    this.newUser = function () {
        UserManager.newUser();
        this.save();
    };
    //metodi dedicati al piemenu:
    /**
     * Il metodo addSibling(target_id) permette di aggiungere una
     * slide sibling alla slide con chiave target_id.
     * In particolare recupera la chiave della SlideList padre
     * della slide con chiave target_id e la posizione di quest'ultima
     * all'interno della SlideList. Se tale posizione esiste
     * viene richiamato il metodo addSlide(parent_id,index) della classe
     * SlideManager per aggiungere una nuova slide alla SlideList con chiave
     * slideList_id. In caso contrario viene lanciato un errore.
     * @return Int
     * @param {target_id} chiave della slide a cui aggiungere una slide sibling
     */
    this.addSibling = function (target_id) {
        delete MS.View.graphic.compact[SlideManager.getParent(target_id)];
        MS.View.graphic.save_compact();
        
        var slideList_id = SlideManager.getParent(target_id),
        target_position = SlideListManager.getElements(slideList_id).indexOf(target_id);
        if (target_position >= 0) {
            return SlideManager.addSlide(slideList_id, target_position + 1);
        } else {
            error(ERR.slide_not_found);
        }
    };
    /**
     * Il metodo addChild(target_id) permette di aggiungere una SlideList
     * come figlia di una slide con chiave target_id. In particolare
     * viene richiamato il metodo addSlideList(parent_id,content_slide)
     * della classe SlideListManager per aggiungere una nuova SlideList alla
     * struttura. Viene poi richiamato il metodo pushChild(slide_id,slideList_id)
     * della classe SlideManager per aggiungere la chiave della nuova SlideList all'array
     * di figli della slide di chiave target_id.
     * @return Slide
     * @param {target_id} chiave della slide a cui aggiungere una SlideList figlia
     */
    this.addChild = function (target_id) {
        delete MS.View.graphic.compact[SlideManager.getParent(target_id)];
        MS.View.graphic.save_compact();
        if (SlideManager.getChild(target_id).length == 9) {
            MessageDispatcher.sendNotification(MEX.slide_max_child);
            return false;
        }
        var new_slideList_id = SlideListManager.addSlideList(target_id);
        return SlideManager.pushChild(target_id, new_slideList_id);
    };
    /**
     * Il metodo moveBranchAsChild sposta un ramo della mindmap come figlio
     * di una slide di chiave destination_id. In particolare viene richiamato il metodo
     * isPreviousOf(slide_left,slide_right) per controllare che la slide con chiave
     * source_id si trovi in posizione precedente rispetto alla slide con chiave
     * destination_id. In caso positivo viene richiamato il metodo sendMessage(message)
     * della classe MessageDispatcher per segnalare che non si può spostare il ramo e viene ritornato
     * il valore false. Altrimenti
     * viene richiamato il metodo addSlideList(parent_id,content_slide)
     * della classe SlideListManager per aggiungere una nuova SlideList alla
     * struttura contenente il ramo da spostare e il metodo
     * pushChild(slide_id,slideList_id) della classe SlideManager per
     * aggiungere la chiave di tale SlideList all'array di figli della slide
     * con chiave destination_id.
     * @return Boolean
     * @param {source_id} chiave della slide da cui parte il ramo da spostare
     * @param {destination_id} chiave della slide a cui aggiungere come figlio il ramo
     */
    this.moveBranchAsChild = function (source_id, destination_id) {
        if (source_id == 0) {
            MessageDispatcher.sendNotification(MEX.unable_to_move_first_slide);
            return false;
        }

        if (SlideManager.getChild(destination_id).length == 9) {
            MessageDispatcher.sendNotification(MEX.slide_max_child);
            return false;
        }

        if (this.isPreviousOf(source_id, destination_id)) {
            MessageDispatcher.sendNotification(MEX.unable_to_move_branch);
            return false;
        }
        
        delete MS.View.graphic.compact[SlideManager.getParent(destination_id)];
        MS.View.graphic.save_compact();
        
        
        /**
         * source_slideList_id contiene il riferimento alla SlideList padre della slide
         * con chiave source_id da cui parte il ramo da spostare
         */
        var source_slideList_id = SlideManager.getParent(source_id),
        /**
         * source_slideList contiene l'array di slide della SlideList con indice source_slideList_id
         */
        source_slideList = SlideListManager.getElements(source_slideList_id),

        source_branch = source_slideList.slice(source_slideList.indexOf(source_id)),
        new_slideList_id = SlideListManager.addSlideList(destination_id, source_branch),
        i;

        SlideManager.pushChild(destination_id, new_slideList_id);
        for (i = 0; i <  source_branch.length; i += 1) {
            SlideListManager.popElement(source_slideList_id, source_branch[i]);
        }
        return true;
    };
    /**
     * Il Metodo moveSlideAsChild(source_id,destination_id) sposta una slide come
     * figlia di un'altra slide. In particolare richiama il metodo
     * isParentOf(slide_parent,slide_child) per controllare se la slide da
     * spostare è padre della slide di destinazione. In caso positivo viene richiamato
     * il metodo sendMessage(message) della classe MessageDispatcher per segnalare che non si
     * può spostare la slide e viene ritornato il valore false. Altrimenti viene richimato
     * il metodo addSlideList(parent_id,content_slide) della classe SlideListManager
     * per aggiungere una nuova SlideList alla struttura contenente la slide da spostare
     * e il metodo pushChild(slide_id,slideList_id) della classe SlideManager
     * per aggiungere all'array di figli della slide con chiave destination_id
     * la chiave della nuova SlideList.
     * @return Boolean
     * @param {source_id} chiave della slide da spostare
     * @param {destination_id} chiave della slide a cui aggiungere la slide figlia
     */
    this.moveSlideAsChild = function (source_id, destination_id) {
        if (source_id == 0) {
            MessageDispatcher.sendNotification(MEX.unable_to_move_first_slide);
            return false;
        }
        if (this.isParentOf(source_id, destination_id)) {
            MessageDispatcher.sendNotification(MEX.unable_to_move_slide);
            return false;
        }
        if (SlideManager.getChild(destination_id).length == 9) {
            MessageDispatcher.sendNotification(MEX.slide_max_child);
            return false;
        }
        
        delete MS.View.graphic.compact[SlideManager.getParent(destination_id)];
        MS.View.graphic.save_compact();
        
        
        //slide.setParent!
        var source_slideList = SlideManager.getParent(source_id),
        new_slideList_id = SlideListManager.addSlideList(destination_id, source_id);
        SlideListManager.popElement(source_slideList, source_id);
        SlideManager.pushChild(destination_id, new_slideList_id);
        return true;
    };
    this.deleteProject = function (id) {
        ProjectManager.deleteProject(id);
    }
    /**
     * Il metodo moveBranchAsSibling(source_id,destination_id) sposta un ramo della mindmap come sibling
     * di una slide di chiave destination_id. In particolare viene richiamato il metodo
     * isPreviousOf(slide_left,slide_right) per controllare se la slide con
     * chiave source_id si trova sul cammino della slide con
     * chiave destination_id. In caso positivo viene richiamato il metodo
     * sendMessage(message) della classe MessageDispatcher per segnalare
     * che non si può spostare il ramo e viene ritornato il valore false.
     * Altrimenti viene recuperata la posizione della slide con chiave destination_id
     * all'interno della SlideList di destinazione a cui aggiungere come sibling il ramo da spostare.
     * Se tale indice esiste viene richiamato il metodo pushElement(slideList_id,slide_id,index)
     * della classe SlideListManager per aggiungere alla SlideList di destinazione la slide
     * da cui parte il ramo da spostare.
     * Altrimenti viene lanciato un errore.
     * @return boolean
     * @param {source_id} chiave della slide da cui parte il ramo da spostare
     * @param {destination_id} chiave della slide a cui aggiungere il ramo come sibling
     */
    this.moveBranchAsSibling = function (source_id, destination_id) {
        if (source_id == 0) {
            MessageDispatcher.sendNotification(MEX.unable_to_move_first_slide);
            return false;
        }

        if (this.isPreviousOf(source_id, destination_id)) {
            console.log(MEX.unable_to_move_branch);
            MessageDispatcher.sendNotification(MEX.unable_to_move_branch);
            return false;
        }
        
        delete MS.View.graphic.compact[SlideManager.getParent(destination_id)];
        MS.View.graphic.save_compact();
        
        var source_slideList_id = SlideManager.getParent(source_id),
        source_slideList = SlideListManager.getElements(source_slideList_id),
        source_branch = source_slideList.slice(source_slideList.indexOf(source_id)),
        /**
         * destination_slideList_id contiene la chiave della SlideList di appartenenza
         *
         */
        destination_slideList_id = SlideManager.getParent(destination_id),
        destination_index = SlideListManager.getElements(destination_slideList_id).indexOf(destination_id),
        i;
        if (destination_index >= 0) {
            //rimuovo le slide dalla slideListPrecedente
            for (i = 0; i < source_branch.length; i += 1) {
                SlideListManager.popElement(source_slideList_id, source_branch[i]);
                SlideManager.setParent(source_branch[i], destination_slideList_id);
                //TODO: verificare i +1
                SlideListManager.pushElement(destination_slideList_id, source_branch[i], destination_index + 1);
                destination_index += 1;
            }
        } else {
            error(ERR.base);
        }
    };
    /**
     * Il metodo moveSlideAsSibling(source_id,destination_id) sposta una slide come
     * sorella di un'altra slide. In particolare richiama il metodo
     * isParentOf(slide_parent,slide_child) per controllare se la slide da
     * spostare è padre della slide di destinazione. In caso positivo viene richiamato
     * il metodo sendMessage(message) della classe MessageDispatcher per segnalare che non si
     * può spostare la slide e viene ritornato il valore false.
     * Altrimenti viene recuperata la posizione della slide con chiave
     * destination_id all'interno della SlideList di destinazione a cui aggiungere come
     * sibling la slide da spostare. Se tale posizione non esiste viene lanciato
     * un errore. Altrimenti viene richiamato
     * il metodo pushElement(slideList_id,slide_id,index)
     * della classe SlideListManager per aggiungere alla SlideList che contiene la slide
     * con chiave destination_id la slide con chiave source_id. Viene infine ritornato il valore true.
     * @return Boolean
     * @param {source_id} chiave della slide da spostare
     * @param {destination_id} chiave della slide a cui aggiungere la slide sibling
     */
    this.moveSlideAsSibling = function (source_id, destination_id) {
        if (source_id == 0) {
            MessageDispatcher.sendNotification(MEX.unable_to_move_first_slide);
            return false;
        }
        if (this.isParentOf(source_id, destination_id)) {
            MessageDispatcher.sendNotification(MEX.unable_to_move_slide);
            return false;
        }
        
        delete MS.View.graphic.compact[SlideManager.getParent(destination_id)];
        MS.View.graphic.save_compact();
        
        
        var source_slideList = SlideManager.getParent(source_id),
        destination_slideList = SlideManager.getParent(destination_id),
        destination_index = SlideListManager.getElements(destination_slideList).indexOf(destination_id);
        if (destination_index >= 0) {
            //rimuovo la slide dalla slidelist precedente
            SlideListManager.popElement(source_slideList, source_id);
            SlideListManager.pushElement(destination_slideList, source_id, destination_index + 1);
            SlideManager.setParent(source_id, destination_slideList);
        } else {
            error(ERR.base);
            return false;
        }
        return true;
    };
    /**
     * Il metodo deleteSlide(target_id) rimuove dalla struttura la slide di chiave
     * target_id. In particolare controlla il valore della chiave da rimuovere. Se
     * la chiave non è 0 significa che la slide da rimuovere non è la radice della mindmap.
     * In questo caso viene richiamato il metodo deleteSlide(slide_id) della classe
     * SlideManager per rimuovere la slide con chiave target_id e tutte le sue SlideList
     * figlie. In caso contrario viene inviato un messaggio per indicare che non si può
     * cancellare la slide radice.
     * @param {target_id} chiave della slide da rimuovere
     */
    this.deleteSlide = function (target_id) {
        if (target_id !== 0) {
            SlideManager.deleteSlide(target_id);
        } else {
            MessageDispatcher.sendNotification(MEX.delete_slide_0);
        }
    };
    /**
     * Il metodo newProject() richiama il metodo addProject() della classe
     * ProjectManager per aggiungere un nuovo progetto all'array che contiene
     * i progetti dell'utente e restituisce tale progetto.
     * @return Int
     */
    this.newProject = function () {
        return ProjectManager.addProject();
    };
    /**
     * Il metodo loadProject(key) richiama il metodo loadProject(key) della
     * classe ProjectManager per caricare il progetto con chiave key creato dall'utente
     * param {key} chiave del progetto da caricare
     */
    this.loadProject = function (key) {
        ProjectManager.loadProject(key);
    };
    /**
     * Il metodo saveMenuInfo(values) salva nel Model i valori contenuti nell'array values.
     * In particolare assegna i rispettivi valori ai campi name e surname
     * dell'oggetto User associato all'attributo user della classe ModelHandler e ai campi
     * title, description, event_description, event_date e location del progetto relativo
     * all'utente. Infine viene richiamato il metodo saveUser() della classe ModelHandler
     * per deserializzare e memorizzare nel localStorage tali informazioni.
     * @param {values} array di informazioni relative all'utente da salvare
     */
    this.saveMenuInfo = function (values) {
        Model.user.projects[Model.project.id].title = values[0];
        Model.user.projects[Model.project.id].description = values[1];
        Model.user.projects[Model.project.id].event_description = values[2];
        Model.user.projects[Model.project.id].event_date = values[3];
        Model.user.projects[Model.project.id].location = values[4];
        Model.saveUser();
    };
    /**
     * Il metodo loadMenuInfo() concatena gli array restituiti dal metodo getProjectDetails()
     * della classe ProjectManager relativi ai progetti dell'utente e ne restituisce
     * il risultato
     * @return String array
     */
    this.loadMenuInfo = function () {
        return UserManager.getUserDetails().concat(ProjectManager.getProjectDetails()); //FIXME:eseguire il merge dei due array
    };
    /**
     * Il metodo SlideTitle(key,slide_title) restituisce il titolo di una slide.
     * In particolare controlla se il parametro slide_title è definito. In caso
     * negativo richiama il metodo getTitle(slide_id) della classe SlideManager
     * per restituire il titolo della slide con chiave key.
     * @return String
     * @param {key} chiave della slide di cui restituire il titolo
     * @param {slide_title} stringa
     */
    this.SlideTitle = function (key, slide_title) {
        if (slide_title === undefined) {
            return SlideManager.getTitle(key);
        }
    };
    /**
     * Il metodo getProjectList() richiama il metodo getProjectList() della classe
     * ProjectManager per restituire una copia dell'array che contiene i progetti
     * dell'utente.
     * @return String array
     */
    this.getProjectList = function () {
        return ProjectManager.getProjectList();
    };
    /**
     * Il metodo setSlideContent(slide_id,content) richiama il metodo setContent(slide_id,content)
     * per settare il contenuto della slide con chiave slide_id e restituisce il valore
     * di ritorno di tale metodo.
     * @return Int o Boolean
     * @param {slide_id} chiave della slide di cui settare il contenuto
     * @param {content} nuovo contenuto della slide
     */
    this.setSlideContent = function (slide_id, content) {
        return SlideManager.setContent(slide_id, content);
    };
    /**
     * Il metodo getSlideContent(slide_id) richiama il metodo getContent(slide_id)
     * della classe SlideManager per restituire il corpo del contenuto della slide con chiave
     * slide_id.
     * @return Boolean o String
     * @param {slide_id} chiave della slide di cui restituire il corpo
     */
    this.getSlideContent = function (slide_id) {
        return SlideManager.getContent(slide_id);
    };
    /*isPreviousOf(slide_left, slide_right) e is ParentOf(slide_child, slide_parent)*/

    /**
     * Controlla che una slide child sia figlia di una slide parent. Per fare ciò si risale
     * il ramo della mindmap partendo dalla slide figlia e richiamando
     * ricorsivamente la funzione per verificare se nel cammino si incontra la
     * slide parent
     * @return Boolean
     * @param {slide_parent} chiave della slide da cerare
     * @param {slide_child} chiave della slide da cui parte la ricerca della slide parent
     */

    this.isParentOf = function (slide_parent, slide_child) {
        if (slide_parent == slide_child) {
            return true;
        }
        var parent = Model.project.slideList[SlideManager.getParent(slide_child)].parent;
        if (parent == slide_parent) { // slide_parent è = al padre della slide figlia
            return true;
        } else if (parent === undefined) { // la slide fa parte della slideList 0 e quindi non ha padre,
            // (le slide della slideList 0 hanno padre undefined)
            return false;
        } else { // richiamo la funzione ricorsivamente per vedere se slide_parent è "nonno" di slide_child
            return this.isParentOf(slide_parent, parent);
        }
    };
    //CHECK: aggiungere documentazione
    //More efficent version
    /**
     * Il metodo isPreviousOf(slide_left,slide_right) controlla che la
     * slide con chiave slide_left si trovi sul cammino della slide con
     * chiave slide_right. Per fare ciò scorre la slideList verso sinistra
     * cercando la slide con chiave slide_left, se non lo trova ed il primo
     * elemento è diverso dalla slide radice (slide 0) ripete la funzione
     * verificando che il padre della slideList sia a destra della slide con
     * chiave slide_left
     * @return Boolean
     * @param {slide_left} chiave della slide da cercare
     * @param {slide_right} chiave della slide da cui parte la ricerca
     */
    this.isPreviousOf = function (slide_left, slide_right) {
        if (slide_left === 0) {
            return true;
        }
        if (slide_right === 0) {
            return false;
        }
        if (slide_left == slide_right) {
            return true;
        }
        /**
         * slideList_id contiene la chiave della SlideList padre della slide con chiave
         * slide_right
         */
        var slideList_id = SlideManager.getParent(slide_right),
        /**
         * slide_parent contiene il riferimento alla slide padre della slideList con indice
         * slideList_id
         */
        slide_parent = Model.project.slideList[slideList_id].parent,
        /**
         * slideList contiene l'array di slide della SlideList con indice slideList_id
         */
        slideList = Model.project.slideList[slideList_id].elements,
        /**
         * index contiene la posizione della slide con chiave slide_right all'interno
         * dell'array che contiene le slide della slideList con indice slideList_id
         */
        index = slideList.indexOf(slide_right);
        /**
         * partendo dalla posizione precedente a quella in cui si trova la slide con chiave
         * slide_right all'interno della SlideList con indice slideList_id
         * controlla il valore della chiave della slide che si trova in posizione k.
         * Se tale chiave è pari alla chiave slide_left restituisce true, se no controlla se è pari a 0.
         * Se sì restituisce false, altrimenti viene controllata la slide di indice k-1 e così via finché
         * non si arriva all'indice -1. Se non è stata trovata alcuna slide con chiave slide_left nella
         * SlideList con indice slideList_id viene richiamata ricorsivamente la funzione per
         * controllare se la slide con chiave slide_left si trova nella SlideList contenente
         * la slide padre della SlideList con indice slideList_id
         */
        for (index -= 1; index >= 0; index -= 1) {
            if (slideList[index] == slide_left) {
                return true;
            } else if (slideList[index] === 0) {
                return false;
            }
        }
        return this.isPreviousOf(slide_left, slide_parent);
    };
    return this;
}

