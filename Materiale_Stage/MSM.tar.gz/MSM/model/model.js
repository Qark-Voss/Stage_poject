/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global fail, ERR, localStorage, Interface */
/*
 * File: model.js
 * Version: 1.0
 * Data creazione: 10/02/2011
 * Data Ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * Mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Riccardo Cucco} correzione degli errori rilevati con JsLint
 * versione: 0.3 12/02/2011 {Riccardo Cucco} aggiunta dei metodi modelHandler()
 * versione: 0.2 11/02/2011 {Riccardo Cucco} aggiunta dei metodi loadObject(), saveObject() 
 * versione: 0.1 09/02/2011 {Riccardo Cucco} creazione classe, aggiunta dei metodi localStorage() e localStorageAdapter()
 *
 * ********Licenza********************************************
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *-------------------------------------------------------------------
 */

var PersistenceInterface = new Interface('PersistenceInterface', ['saveUser', 'saveProject', 'loadUser', 'loadProject']);

/**
 * L'oggetto LocalStorage fornisce le funzionalità di
 * lettura e scrittura nel LocalStorage
 */
function LocalStorage() {
    /**
     * Il metodo write(key,value) restituisce true la scrittura
     * nel localStorage è avvenuta con successo, false altrimenti
     * @return Boolean
     * @param key: Chiave che indica la posizione del localStorage in cui salvare il valore value
     * @param value: Valore da salvare nel localStorage alla posizione key
     */
    this.write = function (key, value) {
        localStorage[key] = value;
        if (localStorage[key] == value) {
            return true;
        }
        return false;

    };
    /**
     * Il metodo read(key) recupera il valore memorizzato in posizione key del localStorage.
     * Viene restituito false nel caso in cui tale valore sia indefinito o sia nullo, altrimenti
     * viene restituito il valore memorizzato.
     * @return: object o false
     * @param key: chiave che indica la posizione del localStorage da cui leggere il valore
     */
    this.read = function (key) {
        var value = localStorage[key];
        if (value === undefined || value === null) {
            return false;
        }
        return value;
    };
    return this;
}

/**
 * L'oggetto LocalStorageAdapter fornisce le funzionalità di salvataggio e caricamento
 * dei dati relativi al progetto.
 */
function LocalStorageAdapter() {
    var local = new LocalStorage(),
    /**
     * Il metodo loadObject(key) richiama il metodo storageRead(key)
     * della classe LocalStorage() che carica il valore memorizzato nella
     * posizione key del localStorage. Se il valore ritornato è false significa
     * che il valore memorizzato nella posizione key è nullo o non definito.
     * In questo caso viene lanciato un errore e viene ritornato false.
     * In caso contrario viene avviata un'operazione di serializzazione del valore.
     * Se tale operazione ha successo viene ritornato l'oggetto serializzato, in caso
     * contrario viene lanciato un messaggio di errore e viene ritornato il valore
     * false.
     * @return: object o false
     * @param key: chiave che indica la posizione del localStorage da cui leggere il valore
     * da serializzare
     */
    loadObject = function (key) {
        var serialized = local.read(key),
        object;
        if (!serialized) {
            fail(ERR.storage_key_not_found);
            return false;
        }
        try {
            object = JSON.parse(serialized);
        } catch (er) {
            fail(ERR.json_invalid_parse);
            return false;
        }
        return object;
    },
    /**
     * Il metodo saveObject(key,object) avvia un'azione di deserializzazione
     * dell'oggetto object. Se l'azione non ha successo viene lanciato un errore
     * e viene ritornato il valore false. In caso contrario viene richiamato il metodo
     * storageWrite(key,value) per memorizzare l'oggetto deserializzato
     * nella posizione key del localStorage e viene restituito il valore ritornato
     * da tale metodo
     * @return: boolean
     * @param object: oggetto da deserializzare
     * @param key: chiave che indica la posizione del localStorage in cui
     * memorizzare l'oggetto deserializzato
     */
    saveObject = function (key, object) {
        var serialized;
        try {
            serialized = JSON.stringify(object);
        } catch (er) {
            fail(ERR.json_invalid_serialization);
            return false;
        }
        return local.write(key, serialized);
    };
    /**
     * Il metodo saveUser(user) richiama il metodo saveObject(key,object)
     * per deserializzare l'oggetto user e memorizzarlo nel localStorage
     * nella posizione corrispondente alla chiave "user" e restituisce il
     * risultato ritornato da tale metodo
     * @return: boolean
     * @param user: oggetto da deserializzare e memorizzare nel localStorage
     */
    this.saveUser = function (user) {
        return saveObject("user", user);
    };
    
    /**
     * Il metodo loadUser() richiama il metodo loadObject(key) per caricare
     * l'oggetto User memorizzato nella posizione del localStorage corrispondente
     * alla chiave "user" e restituisce il risultato ritornato da tale metodo
     * @return: object o false;
     */
    this.loadUser = function () {
        return loadObject("user");
    };
    /**
     * Il metodo newProjectPrototype(key) restituisce un oggetto dotato dei
     * campi id, slide, slideList e content. L'id dell'oggetto ritornato
     * sarà uguale al valore del parametro key.
     * @return: ProjectPrototype object
     * @param: key
     */
    this.newProjectPrototype = function (key) {
        return {
            id : key,
            slide : {modified : false, next_id : 0},
            slideList : {modified : false, next_id : 0},
            content : {modified : false, next_id : 0}
        };
    };
    /**
     * Il metodo loadProject(key) carica un progetto precedentemente creato.
     * Crea un nuovo prototipo di progetto dandogli come id il
     * valore del parametro key. Carica la slide che si trova
     * nella posizione del localStorage corrispondente alla chiave
     * data dalla concatenazione della stringa key e della stringa
     * "_slide". Carica la slideList che si trova
     * nella posizione del localStorage corrispondente alla chiave
     * data dalla concatenazione della stringa key e della stringa
     * "_slideList".
     * Carica il contenuto che si trova nella posizione del localStorage
     * corrispondente alla chiave data dalla concatenazione della stringa
     * key e della stringa "_content". Controlla che gli oggetti caricati
     * non siano nulli. Nel caso in cui non siano nulli vengono memorizzati
     * nei campi dell'oggetto project creato i corrispondenti valori
     * precedentemente caricati. Viene infine ritornato progetto caricato.
     * @return: ProjectPrototype object
     * @param key: identificatore del nuovo progetto
     */
    this.loadProject = function (key) {
        var project = this.newProjectPrototype(key),
        loaded_slide = loadObject(key + "_slide"),
        loaded_slideList = loadObject(key + "_slidelist"),
        loaded_content = loadObject(key + "_content");
        if (loaded_slide) {
            project.slide = loaded_slide;
        }
        if (loaded_slideList) {
            project.slideList = loaded_slideList;
        }
        if (loaded_content) {
            project.content = loaded_content;
        }
        return project;
    };
    /**
     * Il metodo saveProject(project) salva le modifiche di un
     * progetto precedentemente creato.
     * Controlla se le slide del progetto sono state modificate. In caso
     * affermativo viene richiamato il metodo saveObject(key,object) per salvare
     * le slide modificate nella posizione del localStorage corrispondente alla
     * chiave data dalla concatenazione della stringa identificatore del progetto
     * e della stringa "_slide". In caso negativo viene lanciato un messaggio
     * di errore. Se non si riscontrano errori viene controllato se le
     * slideList sono state modificate. In caso
     * affermativo viene richiamato il metodo saveObject(key,object) per salvare
     * le slideList modificate nella posizione del localStorage corrispondente alla
     * chiave data dalla concatenazione della stringa identificatore del progetto
     * e della stringa "_slideList". In caso negativo viene lanciato un messaggio
     * di errore. Se non si riscontrano errori viene controllato se il contenuto
     * è stato modificato. In caso
     * affermativo viene richiamato il metodo saveObject(key,object) per salvare
     * il contenuto modificato nella posizione del localStorage corrispondente alla
     * chiave data dalla concatenazione della stringa identificatore del progetto
     * e della stringa "_content". In caso negativo viene lanciato un messaggio
     * di errore.
     * @return: boolean
     * @param project: progetto di cui salvare le modifiche
     */
    this.saveProject = function (project) {
        var error = false;
        if (project.slide.modified) {
            project.slide.modified = false;
            if (!saveObject(project.id + "_slide", project.slide)) {
                error = true;
                fail(ERR.unsaved_slide);
            }
        }
        if (project.slideList.modified) {
            project.slideList.modified = false;
            if (!saveObject(project.id + "_slidelist", project.slideList)) {
                error = true;
                fail(ERR.unsaved_slideList);
            }
        }
        if (project.content.modified) {
            project.content.modified = false;
            if (!saveObject(project.id + "_content", project.content)) {
                error = true;
                fail(ERR.unsaved_content);
            }
        }
        return !error;
    };
    return this;
}

/**
 * L'oggetto ModelHandler fornisce le funzionalità di accesso al Model
 */
function ModelHandler() {
    this.user = null;
    this.project = null;
    var persistence = new LocalStorageAdapter();
    /**
     * Il metodo loadUser() assegna all'oggetto user precedentemente creato
     * l'oggetto User memorizzato nella posizione del localStorage corrispondente
     * alla chiave "user". Se tale oggetto è nullo o non definito viene ritornato
     * il valore false. In caso contrario viene ritornato il valore true.
     * @return: boolean
     */
    this.loadUser = function () {
        this.user = persistence.loadUser();
        if (!this.user) {
            return false;
        } else {
            return true;
        }
    };
    /**
     * Il metodo loadProject(key) controlla se l'oggetto user
     * precedentemente creato è definito. In caso positivo viene assegnato
     * all'oggetto project precedentemente creato il progetto con id uguale
     * alla chiave key passata come parametro. In caso negativo viene lanciato
     * un messaggio di errore. In questo caso viene ritornato false, altrimenti
     * viene ritornato true.
     * @return: boolean
     * @param key: id del progetto da caricare
     */
    this.loadProject = function (key) {
        if (!this.user) {
            fail(ERR.user_not_loaded);
        } else {
            this.project = persistence.loadProject(key);
        }
        if (!this.project) {
            return false;
        } else {
            return true;
        }
    };
    /**
     * Il metodo saveUser() richiama il metodo saveUser della classe
     * LocalStorageAdapter per deserializzare e memorizzare l'oggetto user
     * precedentemente creato nella posizione del localStorage corrispondente
     * alla chiave "user" e restituisce il risultato ritornato da tale metodo.
     */
    this.saveUser = function () {
        return persistence.saveUser(this.user);
    };
    /**
     * Il metodo saveProject() calcola la data e l'ora correnti e le assegna
     * al campo last_update (che indica la data e l'ora dell'ultimo aggiornamento)
     * del progetto creato dall'utente user e avente l'id dell'oggetto project
     * precedentemente creato. Infine richiama il metodo saveProject(project)
     * del LocalStorageAdapter per salvare le modifiche del progetto project
     * precedentemente creato e restituisce il risultato restituito da tale
     * metodo.
     * @return: boolean
     */
    this.saveProject = function () {
        var date = new Date(),
        now = (date.getHours() < 10 ? "0" : "") + date.getHours() + ":" + (date.getMinutes() < 10 ? "0" : "") + date.getMinutes() + " " + (date.getDate() < 10 ? "0" : "") + date.getDate() + "/" + ((date.getMonth() + 1) < 10 ? "0" : "") + (date.getMonth() + 1) + "/" + date.getFullYear();
        this.user.projects[this.project.id].last_update = now;

        return persistence.saveProject(this.project);
    };
    /**
     * Il metodo newProject(key) crea un nuovo progetto con id uguale alla chiave
     * key e lo assegna all'oggetto project precedentemente creato.
     * @param key: id del nuovo progetto
     */
    this.newProject = function (key) {
        var new_project = persistence.newProjectPrototype(key);
        new_project.slide.modified = true;
        new_project.content.modified = true;
        new_project.slideList.modified = true;
        this.project = new_project;
    };
    this.deleteProject = function (key) {
        delete this.user.projects[key];
        delete localStorage[key+"_slide"];
        delete localStorage[key+"_slidelist"];
        delete localStorage[key+"_content"];
        this.saveUser();
    }
    this.init = function () {
        Interface.ensureImplements(persistence, PersistenceInterface);
    }();
    return this;
}
