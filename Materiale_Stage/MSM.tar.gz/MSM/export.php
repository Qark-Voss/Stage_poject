<?php
if(isset($_POST['project']) && isset($_POST['password'])) {
    include ('./w_connect.php');
    $password = md5($_POST['password']);
    $ip = $_SERVER['REMOTE_ADDR'];
    $project = addslashes($_POST['project']);
    if(mysql_query("   INSERT INTO  `i385234_mindslide`.`presentation` (`id`, `password`, `ip`, `time`, `data`)
    VALUES (NULL, '$password', '$ip', CURRENT_TIMESTAMP, '$project')")) {
        echo "inserted" . mysql_insert_id() . "|" . $_POST['password'];
    } else {
        echo "mysql_error: ".mysql_error();
    };
} else {
    echo "missing data";
}
?>