/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global $, MS, Interface */
/*
 * File: gritterAdapter.js
 * Version: 1.0
 * Data creazione: 20/02/2011
 * Data Ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * Mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Marco Castaldini} correzione degli errori rilevati con JsLint
 * versione: 0.1 20/02/2011 {Marco Castaldini} creazione classe
 *
 * ********Licenza********************************************
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *-------------------------------------------------------------------
 */
var MessageInterface = new Interface('MessageInterface', ['showMessage', 'showNotification']);

function GritterAdapter() {
    this.lastViewed = null;
    this.previewOpen = false;

    this.previewSlide = function (slide_id) {
        if (this.previewOpen !== true) {
            this.showMessage("<div id='preview_title' class='title' style='text-align:center;display:block;font-variant:small-caps;font-weight:20px;color:white;'>" + MS.Model.project.slide[slide_id].title + "</div><div id='preview_content'>" + (MS.Controller.getSlideContent(slide_id) ? MS.Controller.getSlideContent(slide_id) : " ") + "</div>", function () {
                MS.View.comunication.previewOpen = false;
                MS.View.comunication.lastViewed = null;
            }
            );
            this.previewOpen = true;
            this.lastViewed = null;
        } else if (this.lastViewed != slide_id) {
            $('#preview_title').html(MS.Model.project.slide[slide_id].title);
            $('#preview_content').html(MS.Controller.getSlideContent(slide_id) ? MS.Controller.getSlideContent(slide_id) : " ");
            this.lastViewed = slide_id;
        } 
    };
    this.showMessage = function (body, callback) {
        $.gritter.add.call(this, {
            title : " ",
            text : body,
            sticky : true,
            before_close : (callback === undefined ? null : callback)
        });
    };
    this.showNotification = function (body) {
        $.gritter.add.call(this, {
            title: " ",
            time: 2000,
            text: body,
            sticky : false
        });
    };
    return this;
}

MS.View.comunication = new GritterAdapter();
