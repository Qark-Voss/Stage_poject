/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global MS, MEX */
/*
 * File: pieMenu.js
 * Version: 1.0
 * Data creazione: 15/02/2011
 * Data Ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * Mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Mattia Cerantola} correzione degli errori rilevati con JsLint
 * versione: 0.1 15/02/2011 {Mattia Cerantola} creazione classe
 *
 * ********Licenza********************************************
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *-------------------------------------------------------------------
 */
 
MS.View.PieMenu = {
    menu : null,
    last_slide_clicked : null,
    menu_open : false,
    show_mini : false,
    move_source : null,
    move_type : null,
    //data for main pieMenu
    dataPie : [{   label: "presenta",
        perc: "12.5",
        img: "./images/control_play_blue.png",
        btn_function: function () {
            MS.App.presentation(-1, MS.View.PieMenu.last_slide_clicked);
        }
    },
    {   label: "sposta slide",//moveSlide
        perc: "12.5",
        img: "./images/shape_group.png",
        btn_function : function () {
            if (MS.View.PieMenu.last_slide_clicked != 0) {
                MS.View.PieMenu.move_source = MS.View.PieMenu.last_slide_clicked;
                MS.View.PieMenu.move_type = "slide";
                MS.View.comunication.showNotification(MEX.choose_destination);
                MS.View.PieMenu.show_mini = true;
            } else {
                MS.View.comunication.showNotification(MEX.unable_to_move_first_slide);
            }
            MS.View.PieMenu.hideMenu();
        }
    },
    {   label: "sposta ramo",//moveBranch
        perc: "12.5",
        img: "./images/chart_line.png",
        btn_function: function () {
            if (MS.View.PieMenu.last_slide_clicked != 0) {
                MS.View.PieMenu.move_source = MS.View.PieMenu.last_slide_clicked;
                MS.View.PieMenu.move_type = "branch";
                MS.View.comunication.showNotification(MEX.choose_destination);
                MS.View.PieMenu.show_mini = true;
            } else {
                MS.View.comunication.showNotification(MEX.unable_to_move_first_slide);
            }
            MS.View.PieMenu.hideMenu();
        }
    },
    {   label: "elimina",//delete
        perc: "12.5",
        img: "./images/cross.png",
        btn_function: function () {
            if (confirm(MEX.ask_delete_slide)) {
                MS.Controller.deleteSlide(MS.View.PieMenu.last_slide_clicked);
                
            MS.View.PieMenu.hideMenu();
                MS.View.graphic.refresh();
            }
        }
    },
    {   label: "nuovo figlio",//addChild
        perc: "25",
        img: "./images/arrow_down.png",
        btn_function: function () {
            MS.Controller.addChild(MS.View.PieMenu.last_slide_clicked);
            MS.View.PieMenu.hideMenu();
            MS.View.graphic.refresh();

        }
    },
    {   label: "nuovo fratello",//addSibling
        perc: "25",
        img: "./images/arrow_right.png",
        btn_function: function () {
            MS.Controller.addSibling(MS.View.PieMenu.last_slide_clicked);
            MS.View.PieMenu.hideMenu();
            MS.View.graphic.refresh();

        }
    },
    {
        btn_function: function () {
            MS.App.slide(-1, MS.View.PieMenu.last_slide_clicked);
        }
    }],

    //data for mini pieMenu
    dataMini : [
    {   label: "come sibling",//moveSlide
        perc: "50",
        img: "./images/spostaSibling.png",
        btn_function: function () {
            if (MS.View.PieMenu.move_type == "branch") {
                MS.Controller.moveBranchAsSibling(MS.View.PieMenu.move_source, MS.View.PieMenu.last_slide_clicked);
            } else {
                MS.Controller.moveSlideAsSibling(MS.View.PieMenu.move_source, MS.View.PieMenu.last_slide_clicked);
            }
            MS.View.PieMenu.hideMenu();
            MS.View.graphic.refresh();
            MS.View.PieMenu.move_source = null;
            MS.View.PieMenu.move_type = null;
            MS.View.PieMenu.show_mini = false;
            MS.View.PieMenu.hideMenu();

        }
    },
    {label: "come child",//play
        perc: "50",
        img: "./images/spostaChild.png",
        btn_function: function () {
            if (MS.View.PieMenu.move_type == "branch") {
                MS.Controller.moveBranchAsChild(MS.View.PieMenu.move_source, MS.View.PieMenu.last_slide_clicked);
            } else {
                MS.Controller.moveSlideAsChild(MS.View.PieMenu.move_source, MS.View.PieMenu.last_slide_clicked);
            }
            MS.View.PieMenu.hideMenu();
            MS.View.graphic.refresh();
            MS.View.PieMenu.move_source = null;
            MS.View.PieMenu.move_type = null;
            MS.View.PieMenu.show_mini = false;
            MS.View.PieMenu.hideMenu();
        }
    },

    {
        btn_function: function () {
            MS.View.PieMenu.hideMenu();
            MS.View.PieMenu.move_source = null;
            MS.View.PieMenu.move_type = null;
            MS.View.PieMenu.show_mini = false;
        }
    }
    ],
    slideClicked : function (id, evt) {//clicked check if slide was already clicked once
        this.last_slide_clicked = id;
		if (evt.ctrlKey && !isTouchDevice()) {
			MS.Controller.addSibling(id);
			MS.View.graphic.refresh();
		} else if (evt.shiftKey && !isTouchDevice()) {
			MS.Controller.addChild(id);
			MS.View.graphic.refresh();
		} else {
		if (this.menu_open === true) {
			this.hideMenu();
		}
		if (this.show_mini) {
			if (this.last_slide_clicked === this.move_source) {
				MS.View.comunication.showNotification(MEX.unable_to_move);
			} else {
				this.menu = MS.View.graphic.paper.miniPie(evt.clientX, evt.clientY, this.dataMini);
			}
		} else {
			this.menu = MS.View.graphic.paper.pieMenu(evt.clientX, evt.clientY, this.dataPie);
		}
		this.menu_open = true;
		}
    },
    hideMenu : function () {
        var paperDom = this.menu.canvas;
        if (paperDom.parentNode !== null) {
            paperDom.parentNode.removeChild(paperDom);
        }
        this.menu_open = false;
    }
};

