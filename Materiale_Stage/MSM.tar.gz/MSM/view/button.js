/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global $, MS, Interface, jQuery, $ */

/*
 * File: ZPDMenu.js
 * Version: 1.0
 * Data creazione: 15/02/2011
 * Data Ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * Mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Francesca Pastorello} correzione degli errori rilevati con JsLint
 * versione: 0.1 15/02/2011 {Francesca Pastorello} creazione classe
 *
 * ********Licenza********************************************
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *-------------------------------------------------------------------
 */
$(document).ready(function () {
	jQuery('.button').bind({
	    mousedown: function () {
			jQuery(this).addClass('mousedown');
	    },
	    blur: function () {
			jQuery(this).removeClass('mousedown');
	    },
		mouseup: function () {
			jQuery(this).removeClass('mousedown');
		}
	});
});

