/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 1500, indent: 4 */
/*global MS, Raphael, RaphaelZPD, $, window, Interface */

/*
 * File: RaphaelAdapter.js
 * Version: 1.0
 * Data creazione: 15/02/2011
 * Data Ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * Mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Mattia Cerantola} correzione degli errori rilevati con JsLint
 * versione: 0.1 15/02/2011 {Mattia Cerantola} creazione classe
 *
 * ********Licenza********************************************
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *-------------------------------------------------------------------
 */
 
var GraphicInterface = new Interface('GraphicInterface', ['drawList', 'drawSlide', 'refresh']);

function RaphaelAdapter() {
    this.compact = {};
    this.save_compact = function () {
        localStorage['compacted'] = JSON.stringify(this.compact);
    };
    var graph_const = {
        slide_width : 200,
        slide_height : 80,
        slidelist_spacing : 50,
        slide_spacing : 20,
        vertical_spacing : 100,
        single_slide_color : "#2e83ff",
        wrong_destination_color : "#cccccc"
    },
    first_load = true;
    if (localStorage['compacted']) {
        this.compact = JSON.parse(localStorage['compacted']);
    }

    Raphael.fn.slide = function drawSlide(slide_id, x, y, slide_title, color) {

        var paper = this,
        token = [],
        i = 0,
        j = i,
        result,
        word_id,
        testo,
        slide,
        rettangolo;

        if (slide_title.length > 23) {
            token = slide_title.split(" ");
            result = [""];
            for (word_id = 0; word_id < token.length; word_id += 1) {
                if (token[word_id].length > 23) {
                    if (result[result.length - 1].length === 0) {
                        result[result.length - 1] = token[word_id];
                    } else {
                        result[result.length] = token[word_id];
                    }
                } else {
                    if (result[result.length - 1].length + token[word_id].length < 23) {
                        result[result.length - 1] = result[result.length - 1] + " " + token[word_id];
                    } else {
                        result[result.length] = token[word_id];
                    }
                }
            }
            slide_title = result.join('\n');
        }

        testo = paper.text(x + (graph_const.slide_width / 2), y + (graph_const.slide_height / 2), slide_title);//posizionamento del testo
        testo.attr({'font-size': 18});
        rettangolo = paper.rect(x, y, graph_const.slide_width, graph_const.slide_height, 10).attr({'title' : slide_title});

        if (color === undefined) {
            rettangolo.attr({'fill' : '#E5F5FF', 'stroke' : 'black', 'stroke-width' : 1});
        } else {
            rettangolo.attr({
                'fill' : color,
                'stroke' : color,
                'stroke-width' : 2,
                'stroke-opacity' : 1,
                'fill-opacity' : 0.3
            });
        }

        testo.slide_id = slide_id;
        rettangolo.slide_id = slide_id;

        if (first_load && paper.ZPDPanTo !== undefined && slide_id == MS.App.selected_slide) {
            paper.ZPDPanTo(- (x + graph_const.slide_width / 2) + $(window).width() / 2, - (y + graph_const.slide_height / 2) + $(window).height() / 2);
        }

        return rettangolo;
    };
    Raphael.fn.compacter = function (x, y, list_id, list_color) {
        var compacter,
        bg = this.rect(x - 18, y + 14, 23, graph_const.slide_height - 28, 5),
        right_tab = {},
        alt = "Comprimi la lista",
        simbol = "{";
        if (MS.View.graphic.compact[list_id]) {
            alt = "Espandi la lista";
            simbol = "}";
            //aggiungo un overlay a destra
            right_tab.x = x+graph_const.slide_width;
            right_tab.y = y;
            right_tab.width = 25;
            right_tab.height = graph_const.slide_height;
            right_tab.draw = function(paper) {
                paper.rect(right_tab.x - 20, right_tab.y, right_tab.width, right_tab.height, 10).attr(
                {stroke : list_color,
                    "stroke-width" : 2,
                    //"fill" : list_color,
                    "fill-opacity" : 0.3,
                    "clip-rect" : (right_tab.x - 10) + "," + (right_tab.y - 2) + "," + right_tab.width + "," + (graph_const.slide_height + 4)
                });
            }
            right_tab.draw(this);
            right_tab.x += 5;
            right_tab.draw(this);
            right_tab.x += 5;
            right_tab.draw(this);
        }

        bg.toBack();
        bg.attr({title : alt, stroke : list_color, "stroke-width" : 2, fill : list_color, "fill-opacity" : 0.3, "clip-rect" : (x - 20) + "," + (y + 2) + "," + 20 + "," + (graph_const.slide_height - 4)});
        bg.list_id = list_id;

        //compacter = this.image("./images/collapse.png", x -18 , y + graph_const.slide_height/2 -18 , 16, 16);
        compacter = this.text(x - 9, y + (graph_const.slide_height / 2) - 3, simbol);
        compacter.toBack();
        compacter.attr({cursor : "pointer", "stroke" : "#dadada", "fill" : list_color, "font-size" : 40});

		if(DetectAndroid() || !isTouchDevice())
		{bg.mouseover( function () {
				this.animate({"fill-opacity" : 0.6, "stroke-width" : 4}, 300);
			}).mouseout( function () {
				this.animate({"fill-opacity" : 0.3, "stroke-width" : 2}, 300);
			});
			bg.click( function () {
				this.animate({"fill-opacity" : 0.3, "stroke-width" : 2}, 300);
				if (MS.View.graphic.compact[this.list_id]) {
					delete MS.View.graphic.compact[this.list_id];
				} else {
					MS.View.graphic.compact[this.list_id] = true;
				}
				MS.View.graphic.save_compact();
				MS.View.graphic.refresh();
			});
		}
		else
		{bg.touchstart( function (evt) {
				if (MS.View.graphic.compact[this.list_id]) {
					delete MS.View.graphic.compact[this.list_id];
				} else {
					MS.View.graphic.compact[this.list_id] = true;
				}
				MS.View.graphic.save_compact();
				MS.View.graphic.refresh();
				evt.preventDefault();
			});
		}
    };
    this.paper = new Raphael(0, 0, $(window).width(), $(window).height());
    this.mindmaphelpOpen = false;
    this.presentationhelpOpen = false;

    /**
     * Il metodo drawList(paper,x,y,index) disegna una SlideList. In particolare
     * recupera la lunghezza dell'array che contiene le chiavi delle slide della SlideList
     * con indice index e per ogni slide della SlideList richiama il metodo
     * drawSlide(paper,x,y,index,color) per disegnare la slide alle coordinate
     * x,y. Se la lista disegnata contiene più di un elemento vengono disegnate le
     * connessioni sibling tra le slide. Viene infine restituita la lista
     */
    this.drawList = function (paper, x, y, index, color) {
        var drawed_slide = [],
        slide_id,
        i,
        list_color = graph_const.single_slide_color,
        slidelist_set = this.paper.set(),
        list_element = MS.Model.project.slideList[index].elements,
        element_length = list_element.length,
        draw_compacter = false;

        if (element_length > 1) {
            list_color = Raphael.getColor();
            draw_compacter = true;
        } else if (MS.Model.project.slide[list_element[0]].child.length > 0) {
            draw_compacter = true;
        }

        drawed_slide[0] = this.drawSlide(paper, x, y, list_element[0], list_color, this.compact[index]);//disegna la slide alle coordinate x,y

        x = drawed_slide[0].child_max_x + graph_const.slide_spacing;

        if( draw_compacter) {
            paper.compacter(drawed_slide[0].attrs.x, drawed_slide[0].attrs.y, index, list_color);
        }

        slidelist_set.push(drawed_slide[0]);
        if (!this.compact[index] && MS.Model.project.slide[list_element[0]].child.length > 0) { //FIXME: aggiungere lo spazio solo se non è compattata!
            x += graph_const.slidelist_spacing;
        }

        if (!this.compact[index] && element_length > 1) {
            for (i = 1; i < element_length; i += 1) {
                slide_id = list_element[i];
                drawed_slide[i] = this.drawSlide(paper, x, y, slide_id, list_color);//disegna la slide alle coordinate x,y
                x = drawed_slide[i].child_max_x + graph_const.slide_spacing;
                slidelist_set.push(drawed_slide[i]);
                if (MS.Model.project.slide[slide_id].child.length > 0) {
                    x += graph_const.slidelist_spacing;
                }
            }

            //disegna le connessioni sibling se esistono
            if (drawed_slide.length > 1) {
                for (i = 0; i < drawed_slide.length - 1; i += 1) {
                    paper.connection(drawed_slide[i], drawed_slide[i + 1], list_color);
                }
				if(DetectAndroid() || !isTouchDevice())
				{
                slidelist_set.mouseover( function () {
                    slidelist_set.animate({"fill-opacity" : 0.6, "stroke-width" : 4}, 300);
                }).mouseout( function () {
                    slidelist_set.animate({"fill-opacity": 0.3, "stroke-width" : 2}, 300);
                });
				}
				else{
				 slidelist_set.touchstart( function () {
                    slidelist_set.animate({"fill-opacity" : 0.6, "stroke-width" : 4}, 300);
                }).touchend( function () {
                    slidelist_set.animate({"fill-opacity": 0.3, "stroke-width" : 2}, 300);
                });
				}
            }

        }

        return drawed_slide;
    };
    /**
     * Il metodo drawSlide(paper,x,y,index,color) disegna una slide. In particolare
     * controlla se la slide che si trova in posizione index dell'array di slide
     * del progetto dell'utente ha almeno un figlio. In caso positivo
     * richiama il metodo drawList(paper,x,y,index) per disegnare le SlideList figlie.
     * Vengono infine disegnati il rettangolo della slide e
     * le connessioni parent/child e viene restituito l'elemento disegnato.
     */
    this.drawSlide = function (paper, x, y, index, color, compacted) {
        var drawed_slideList = [],
        xmax = x,
        j,
        temp_slidelist,
        rect;
        if (!compacted && MS.Model.project.slide[index].child.length > 0) {
            for (j = 0; j < MS.Model.project.slide[index].child.length; j += 1) {
                temp_slidelist = this.drawList(paper, xmax, y + graph_const.slide_height + graph_const.vertical_spacing, MS.Model.project.slide[index].child[j]);
                drawed_slideList[j] = temp_slidelist;
                xmax = temp_slidelist[temp_slidelist.length - 1].child_max_x + graph_const.slidelist_spacing;
                if (j == MS.Model.project.slide[index].child.length - 1) {
                    xmax -= graph_const.slidelist_spacing;
                }
            }
            if (MS.Model.project.slide[index].child.length > 1) {
                xmax += graph_const.slidelist_spacing;
            }
        }
        if (xmax != x) {
            rect = paper.slide(index, (xmax - graph_const.slide_width + x) / 2, y, MS.Model.project.slide[index].title, color);//disegna il rettangolo della slide
        } else {
            rect = paper.slide(index, x, y, (MS.Model.project.slide[index].title ? MS.Model.project.slide[index].title : "slide #"+index ), color);//disegna il rettangolo della slide
            xmax = x + graph_const.slide_width;
        }

        for (j = 0; j < drawed_slideList.length; j += 1) {//disegna le connessioni parent/child
            parent_connection = paper.connection(rect, drawed_slideList[j][0], drawed_slideList[j][0].attrs.stroke);

        }
		
		if(DetectAndroid() || !isTouchDevice())
		{
			rect.mouseover( function () {
				MS.View.comunication.previewSlide(this.slide_id);
			}).click( function (evt) {
				MS.View.PieMenu.slideClicked(this.slide_id, evt);
			});
		}
		else
		{
			rect.touchstart( function () {
				MS.View.comunication.previewSlide(this.slide_id);
			}).click( function (evt) {
				MS.View.PieMenu.slideClicked(this.slide_id, evt);
			});
		}
        rect.child_max_x = xmax;
        return rect;
    };
    /**
     * Il metodo refresh() richiama il metodo drawList(paper,x,y,index) per
     * disegnare la nuova mindmap nell'area di lavoro.
     */
    this.refresh = function () {
        this.paper.clear();
        Raphael.getColor.reset();
        this.drawList(this.paper, 0, 0, 0);
        first_load = false;
    };
}

MS.View.graphic = new RaphaelAdapter();

//MS.View.GraphicAdapter.disegnaMenu(); //FIXME: ripristinare

