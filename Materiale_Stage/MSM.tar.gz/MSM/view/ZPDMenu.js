/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global MS, Interface, RaphaelZPD, localStorage */
/*
 * File: ZPDMenu.js
 * Version: 1.0
 * Data creazione: 15/02/2011
 * Data Ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * Mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Elisa Canella} correzione degli errori rilevati con JsLint
 * versione: 0.1 15/02/2011 {Elisa Canella} creazione classe
 *
 * ********Licenza********************************************
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *-------------------------------------------------------------------
 */



var ZPDInterface = new Interface('ZPDInterface', ['zoomIn', 'zoomOut', 'moveRight', 'moveLeft', 'moveUp', 'MoveDown']);

function RaphaelZPDAdapter() {
    var move_gap = 20,
    zoom_gap = 20,
    zpd = new RaphaelZPD(MS.View.graphic.paper, { zoom: true, pan: true, drag: false });

    this.menuOpen = false;
    /**
     * Il metodo zoomIn() imposta le coordinate per diminuire il livello di dettaglio
     * della mindmap
     */
    this.zoomIn = function () {
        var stub = {target : {ownerDocument : document},
            clientX : document.width / 2,
            clientY : document.height / 2,
            detail : -5 };
        zpd.handleMouseWheel(stub);
    };
    /**
     * Il metodo zoomOut() imposta le coordinate per aumentare il livello di dettaglio
     * della mindmap
     */
    this.zoomOut = function () {
        var stub = {target : {ownerDocument : document},
            clientX : document.width / 2,
            clientY : document.height / 2,
            detail : 5};
        zpd.handleMouseWheel(stub);

    };
    /**
     * Il metodo moveRight() imposta le coordinate per spostare a destra la mindmap 
     */
    this.moveRight = function () {
        zpd.handleMouseDown({
            target : {
                ownerDocument : document,
                tagName : "svg"
            },
            clientX : document.width / 2,
            clientY : document.height / 2
        }
        );
        zpd.handleMouseMove({target : {ownerDocument : document},
            clientX : document.width / 2 - 100,
            clientY : document.height / 2}
        );
        zpd.handleMouseUp({target : {ownerDocument : document}});

    };
    /**
     * Il metodo moveLeft() imposta le coordinate per spostare s sinistra la mindmap
     */
    this.moveLeft = function () {
        zpd.handleMouseDown({
            target : {
                ownerDocument : document,
                tagName : "svg"
            },
            clientX : document.width / 2,
            clientY : document.height / 2
        }
        );
        zpd.handleMouseMove({
            target : {
                ownerDocument : document
            },
            clientX : document.width / 2 + 100,
            clientY : document.height / 2
        }
        );
        zpd.handleMouseUp({
            target : {
                ownerDocument : document
            }
        });

    };
    this.moveUp = function () {
        zpd.handleMouseDown({
            target : {
                ownerDocument : document,
                tagName : "svg"
            },
            clientX : document.width / 2,
            clientY : document.height / 2
        });
        zpd.handleMouseMove({
            target : {
                ownerDocument : document
            },
            clientX : document.width / 2,
            clientY : document.height / 2 + 100
        });
        zpd.handleMouseUp({
            target : {
                ownerDocument : document
            }
        });

    };
    /**
     * Il metodo moveDown() imposta le coordinate per spostare in basso la mindmap
     */
    this.moveDown = function () {
        zpd.handleMouseDown({
            target : {
                ownerDocument : document,
                tagName : "svg"
            },
            clientX : document.width / 2,
            clientY : document.height / 2
        });
        zpd.handleMouseMove({target : {ownerDocument : document},
            clientX : document.width / 2,
            clientY : document.height / 2 - 100});
        zpd.handleMouseUp({target : {
                ownerDocument : document
            }
        });

    };
    /**
     * Il metodo drawMenu() disegna il menu. In particolare controlla se il menu è già stato disegnato. 
     * In caso negativo utilizza le funzionalità offerte dalla classe GritterAdapter
     * per disegnare e visualizzare il menu.
     */
    this.drawMenu = function () {
        if (this.menuOpen === false) {
            this.menuOpen = true;
            localStorage['zpd'] = true;
            MS.View.comunication.showMessage('<img src = "./images/up.png" onclick = "MS.View.zpd.moveUp();" style="cursor:pointer; margin-right:13px;" alt="spostati in su"/><img src="./images/down.png" onclick = "MS.View.zpd.moveDown();" style="cursor:pointer; margin-right:30px;" alt="spostati in gi&ugrave;"/><img src="./images/left.png" onclick = "MS.View.zpd.moveLeft();" style="cursor:pointer; margin-right:13px;" alt="spostati a sinistra"/><img src="./images/right.png" onclick = "MS.View.zpd.moveRight();" style="cursor:pointer; margin-right:65px;" alt="spostati a destra"/><img src="./images/zoomin.png" onclick = "MS.View.zpd.zoomIn();" style="cursor:pointer; margin-right:13px;" alt="zoom +"/><img src="./images/zoomout.png" onclick = "MS.View.zpd.zoomOut();" style="cursor:pointer;" alt="zoom -"/>', function() {
                MS.View.zpd.menuOpen = false;
                localStorage['zpd'] = false;
            }
            );
        }
    }
};


MS.View.zpd = new RaphaelZPDAdapter();


if (localStorage['zpd'] !== 'false') {
   MS.View.zpd.drawMenu();
}
