/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 1200, indent: 4 */
/*global $, MS, Controller, console, window */
/*
 * File: projectMenu.js
 * Version: 1.0
 * Data creazione: 15/02/2011
 * Data Ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * Mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Elisa Canella} correzione degli errori rilevati con JsLint
 * versione: 0.2 20/02/2011 {Elisa Canella} aggiunta della funzione saveMenuInfo
 * versione: 0.1 15/02/2011 {Elisa Canella} creazione classe
 *
 * ********Licenza********************************************
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *-------------------------------------------------------------------
 */

MS.View.ProjectMenu = {
    loadMenuInfo : function () {
        var project_details = MS.Controller.loadMenuInfo(),
        last = project_details[8],
        update_year = parseInt(last.slice(12, 16), null),
        update_month = parseInt(last.slice(9, 12), null) - 1,
        update_day = parseInt(last.slice(6, 8), null),
        today = new Date();
        if (today.getFullYear() == update_year && today.getMonth() == update_month && today.getDate() == update_day) {
            last = last.slice(0, 5);
            $("#save_time").html("&nbsp;" + last);
        } else {
            $("#save_time").html("");
        }

        $("#title").html(project_details[3] !== "" ? project_details[3]:"[click to modify]");
        $("#description").html(project_details[4] !== "" ? project_details[4]:"[click to modify]");
        $("#event_description").html(project_details[5] !== "" ? project_details[5]:"[click to modify]");
        $("#event_date").val(project_details[6]);
        $("#location").html(project_details[7] !== "" ? project_details[7]:"[click to modify]");
        $("#last_update").html(last);
        $("#creation_date").html(project_details[9]);


    },
    saveMenuInfo : function () {
        MS.Controller.saveMenuInfo([$("#title").html(),
        $("#description").html(),
        $("#event_description").html(),
        $("#event_date").val(),
        $("#location").html()]);
    }
};

$("document").ready(function () {
    
    $(".button").css("cursor", "pointer");
    $(".button").toggleClass("minibutton", true);


    $(".save").click(function () {
        MS.Controller.save();
        if ($("div#panel").css('display') == "block") {
            $("div#panel").slideUp("slow");
            $("#toggle a").toggle();
        }
        MS.View.ProjectMenu.loadMenuInfo();
        return false;
    });
    $.datepicker.setDefaults($.datepicker.regional["it"]); //FIXME: cercare il bugolo

    $("#event_date").datepicker({
        onSelect: function (dateText, inst) {
            MS.View.ProjectMenu.saveMenuInfo();
        }
    });

    $(".open").click(function () {
        $("div#panel").slideDown("slow");
        return false;
    });
    $(".close").click(function () {
        $("div#panel").slideUp("slow");
        return false;
    });
    
    $("#callmap").click(function () {
        MS.View.zpd.drawMenu();
    });
    
    
        
    $("#toggle a").click(function () {
        $("#toggle a").toggle();
    });
   
});