/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 1200, indent: 4 */
/*global $, MS, Controller, console, window, localStorage, jQuery */

/**********Info******************************************
 * File: presentation.js
 * Versione: 1.0
 * Data creazione: 17/02/2011
 * Data ultima modifica: 28/02/2011
 * 
 * Gruppo: IronMad Project
 * E-mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.2 14/03/2011 {Deborah Rizzi} creata funzione nascondiSlide()
 * versione: 1.1 02/03/2011 {Deborah Rizzi} aggiornamento funzioni manageControl(), goToSlide(), handleKeys(), disabilitaTemi(), create funzioni goToChild(), goToSlideView(), inizializza()
 * versione: 1.0 28/02/2011 {Deborah Rizzi} correzione degli errori rilevati con JsLint
 * versione: 0.4 22/02/2011 {Deborah Rizzi} aggiunta della funzione presentationHelp()
 * versione: 0.3 21/02/2011 {Deborah Rizzi} aggiunta della funzione bottoni(), goToMindMap(), goToSlide(), modifica della funzione handleKeys()
 * versione: 0.2 20/02/2011 {Deborah Rizzi} aggiunta delle funzioni toArray(), queryAll, changeTheme(), disabilitaTemi() 
 * versione: 0.1 17/02/2011 {Deborah Rizzi} creazione classe e aggiunta delle funzioni manageControls() e animazione(), handleKeys(), addEventListener()
 * 
 * ********Licenza********************************************
 * 
 *This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 */



var slide_corrente, 
	currentPosition, 
	deltaMove = 0, 
	numberOfSlides,
	width,
	height,
	slideHeight,
	slideWidth,
	slide_assoc,
	project_info,
	slideList,
	numFigli = [],
	slide,
	slideList_id,
    parent_id,
	padre1 = false,
	padre2 = false,
    slide_title,
    slide_content,
    child_array,
	listaBottoni = [],
	toArray = function (list) {
        return Array.prototype.slice.call(list || [], 0);
    },
    queryAll = function (query, root) {
        return toArray(document.querySelectorAll(query));
    },
	bottoni = function () {
		$('.dock2').Fisheye(
			{
				maxWidth: 60,
				items: 'a',
				itemsText: 'span',
				container: '.dock-container2',
				itemWidth: 40,
				proximity: 80,
				alignment : 'left',
				valign: 'bottom',
				halign : 'center'
			}
		);
	},
	animazione = function () {
		$('#slideInner').animate({
			'marginLeft' : slideWidth * (-currentPosition)
		});
		slide_corrente = slide_assoc[slideList.elements[currentPosition]].id;
	},
	manageControls = function (position) {
		$('.bottoni').html('');
		if (listaBottoni[position] !== '') {
			$('.bottoni').html('<div class="dock dock2"><div class="dock-container2">' + listaBottoni[position] + '</div></div>');
			bottoni();
		}
	};
var nascondiSlide = function () {
	for (var i = 0; i < numberOfSlides; i += 1){
			$('#frecciasx' + i).toggleClass("slideNascosta", true);
			$('#frecciadx' + i).toggleClass("slideNascosta", true);
		}
	if (numberOfSlides > 10) {
		
		for (i = currentPosition - 2; i < currentPosition + 3; i += 1) {
			$('#slide_' + i).toggleClass("slideNascosta", false);
		}
		for (i = 1; i < currentPosition - 2; i += 1) {
			$('#slide_' + i).toggleClass("slideNascosta", true);
		}
		for (i = currentPosition + 3; i < numberOfSlides - 1; i += 1) {
			$('#slide_' + i).toggleClass("slideNascosta", true);
		}
		i = currentPosition - 2;
		if ((i) >= 2) {
			$('#frecciasx' + i).toggleClass("slideNascosta", false);
		}
		i = currentPosition + 2;
		if ((i) <= (numberOfSlides - 3)) {
			$('#frecciadx' + i).toggleClass("slideNascosta", false);
		}
	}
};
function goToMindmap() {
    MS.App.mindmap(-1, slide_corrente);
}

function goToSlideView() {
    MS.App.slide(-1, slide_corrente);
}

function goToChild(figlio) {
	slide = slide_assoc[slideList.elements[currentPosition]];
	MS.App.presentation(MS.App.selected_project, MS.Model.project.slideList[slide.child[figlio]].elements[0]);
}

function goToSlide(id) {
	$('#slide_' + currentPosition).toggleClass("slideCorrente", false);
	currentPosition = id;
    $('#slide_' + currentPosition).toggleClass("slideCorrente", true);
    manageControls(currentPosition);
    animazione();
    nascondiSlide();
}

function changeTheme() {
	var linkEls = queryAll('link.theme'),
    sheetIndex = 0;
    linkEls.forEach(function (stylesheet, i) {
		if (!stylesheet.disabled) {
			sheetIndex = i;
		}
    });
    linkEls[sheetIndex].disabled = true;
    linkEls[(sheetIndex + 1) % linkEls.length].disabled = false;
    localStorage['tema'] = (sheetIndex + 1) % linkEls.length;
}

var disabilitaTemi = function () {
	var linkEls = queryAll('link.theme'),
    tema = (localStorage['tema']) === (undefined) ? 2 : localStorage['tema'];
    tema = (tema === null ? 2 : tema);
    localStorage['tema'] = tema;
    linkEls[0].disabled = true;
    linkEls[1].disabled = true;
    linkEls[2].disabled = true;
    linkEls[tema].disabled = false;
};

var handleKeys = function (e) {
	if (e.keyCode === 37) { //left arrow
		if (currentPosition > 0 && currentPosition <= numberOfSlides - 1) {
			goToSlide(currentPosition - 1);
		}
	} 
	else if (e.keyCode === 38) { //up arrow
		if (parent_id !== 0) {
			MS.App.presentation(MS.App.selected_project, parent_id);
		} 
		else if (slideList_id !== 0) {
			MS.App.presentation(MS.App.selected_project, 0);
        }
	} 
	else if (e.keyCode === 39) { //right arrow
		if (currentPosition >= 0 && currentPosition < numberOfSlides - 1) {
			goToSlide(currentPosition + 1);
        }
	} 
	else if (e.keyCode === 84) {
		changeTheme();
    } 
    else if ((e.keyCode >= 49) && (e.keyCode <= 57)) { // numeri
		if (numFigli[currentPosition] > (e.keyCode - 49)) {
			goToChild(e.keyCode - 49);
        }
    }
};

var inizializza = function () {
	var i,
	j,
	slides;
	for (i = 0;i < numberOfSlides;i += 1) {
        $('#listaSlide').append('<li class="slide" id="slide' + i + '"></li>');
        slide = slide_assoc[slideList.elements[i]];
        slide_title = slide.title;
        slide_content = (MS.Controller.getSlideContent(slideList.elements[i])) === false ? "&nbsp;" : MS.Controller.getSlideContent(slideList.elements[i]);
        $('#slide' + i).append('<h1>' + slide_title + '</h1> <div id=slide_content><p>' + slide_content + '</p></div>');
        child_array = [];
        numFigli[i] = slide.child.length;
        listaBottoni[i] = '';
        for (j = 0; j < numFigli[i]; j += 1) {
            listaBottoni[i] = listaBottoni[i] + '<a class="dock-item2" if(isTouchDevice()) ontouchstart="goToChild(' + j + ')" else onclick="goToChild(' + j + ')"><span>' + slide_assoc[MS.Model.project.slideList[slide.child[j]].elements[0]].title + '</span><img src="./images/' + (j + 1) + '.png" alt="home" /></a>';
        }
        $('#indiciSlide').append('<span class="freccia" id="frecciasx' + i + '">&#8592;</span> <a onClick="goToSlide(' + i + ')" class="linkSlide" id="slide_' + i + '">' + (i + 1) + '</a> <span class="freccia" id="frecciadx' + i + '">&#8594;</span>');
		$('#slide_content div').css('position', 'relative');
    }
    nascondiSlide();
    $('#slidesContainer').append('<p id=slide_footer>' + project_info + '</p>');

    $('#slide_' + currentPosition).toggleClass("slideCorrente", true);
   
    $('#slideshow').append('<div class="bottoni" id="bottoni"></div>');
   
    // se la slideList ha un padre aggiungo il collegamento ad esso
    if (parent_id !== 0) {  
        $('#slideshow').append('<a onclick="MS.App.presentation(MS.App.selected_project,' + parent_id + ');" id="padre">Torna a: ' + slide_assoc[parent_id].title + ' </a>');
    } else if (slideList_id !== 0) { // il padre è 0 ma la slideList è diversa da 0 quindi la slide è figlia della prima slide
        $('#slideshow').append('<a onclick="MS.App.presentation(MS.App.selected_project,' + 0 + ');" id="padre">Torna a: ' + slide_assoc[MS.Model.project.slideList[0].elements[0]].title + '</a>');
    }
    
    $('#slideshow').css('width', width);
    $('#slideshow').css('height', slideHeight);
    $('#slidesContainer').css('width', slideWidth);
    $('#slidesContainer').css('height', slideHeight);
    $('.slide').css('width', slideWidth);
    $('.slide').css('height', slideHeight-100);
    
     // Remove scrollbar in JS
    $('#slidesContainer').css('overflow', 'hidden');
	slides = $('.slide');
    // Wrap all .slides with #slideInner div
    slides
    .wrapAll('<div id="slideInner"></div>')
    // Float left to display horizontally, readjust .slides width
    .css({
        'float' : 'left',
        'width' : slideWidth
    });

    // Set #slideInner width equal to total width of all slides
    $('#slideInner').css('width', slideWidth * numberOfSlides);

    $('#slideInner').css('margin-left', slideWidth * (-currentPosition));

   
    
};



$(document).ready(function () {
    if (MS.App.selected_project == -1) {
        MS.App.home();
    }
    MS.Controller.loadProject(MS.App.selected_project);
    var p_details = MS.Controller.loadMenuInfo(MS.App.selected_project);
    project_info = p_details[0] + ' ' + p_details[1] + ' | ' + p_details[3] + ' <br /> ' + p_details[6] + ' ' + p_details[5] + ' | ' + p_details[7];
    project_info = project_info.replace(/\[click to modify\]/g, '');
    slide_assoc = MS.Model.project.slide;
    width = document.body.clientWidth;
    height = document.documentElement.clientHeight;
    slideHeight = height - 55;
   
    var slideList_assoc = MS.Model.project.slideList,
    content_assoc = MS.Model.project.content,
    slide_id = (MS.App.selected_slide == -1 ? 0 : MS.App.selected_slide);
    if (slide_assoc[slide_id] === undefined) {
		goToMindmap();
    }
   
    slideList = slideList_assoc[slide_assoc[slide_id].parent];
    slideList_id = slideList.id;
    parent_id = (slideList_assoc[slide_assoc[slide_id].parent].parent === undefined ? 0 : slideList_assoc[slide_assoc[slide_id].parent].parent);
    slideWidth = width - 50;
    numberOfSlides = slideList.elements.length;
    slide_corrente = slide_id;
    currentPosition = slideList.elements.indexOf(parseInt(slide_id));
    
    inizializza();
    
    $("#helpMindmap").click(function () {
        MS.View.GraphicAdapter.disegnaHelpMindmap();
    });

    disabilitaTemi();
   
    document.addEventListener('keydown', function (e) {
        handleKeys(e);
    }, false);
   
    manageControls(currentPosition);

    $('.dock2').hover(function () {
        $('#slide_footer').css("display", "none"); 
    }, function () {
        $('#slide_footer').css("display", "block"); 
    });

});


var helpOpen = false;

function presentationHelp() {
    if (helpOpen === false) {
        helpOpen = true;
		if(!isTouchDevice())
		{
        MS.View.comunication.showMessage('<font size="2px"><b>T</b>: cambia lo stile della presentazione<br><b>FRECCIA DESTRA</b>: passa al sibling successivo<br><b>FRECCIA SINISTRA</b>: passa al sibling precedente<br><b>FRECCIA SU</b>: passa alla slide padre<br><b>CLICK </b><img src="./images/numerosibling.jpg" />: passa al sibling numero #<br><b>CLICK </b><img src="./images/mininumber.png" />: passa al child numero #<br><br><img src="./images/house.png">: torna alla pagine dei progetti<br><img src="./images/sitemap_color.png">: torna alla mindmap view<br><img src="./images/slide.png">: modifica la slide<br><img src="./images/help.png">: apre il menù di help</font>', function () {
            helpOpen = false;
        });
		}
		else
		{
        MS.View.comunication.showMessage('<font size="1.5px"><b><u>OPERAZIONI CON 1 DITO</u><br>TRASCINAMENTO VERSO SINISTRA</b>: passa al sibling successivo<br><b>TRASCINAMENTO VERSO DESTRA</b>: passa al sibling precedente<br><b>TRASCINAMENTO VERSO IL BASSO</b>: passa alla slide padre<br><b>TRASCINAMENTO VERSO L\'ALTO</b>: annulla qualsiasi spostamento in coda<br><b>TOUCH </b><img src="./images/numerosibling.jpg" />: passa al sibling numero #<br><b>TOUCH </b><img src="./images/mininumber.png" />: passa al child numero #<br><hr width=100% size=1 color=#FFF><b><u>OPERAZIONI CON 2 DITA</u><br>TRASCINAMENTO VERSO SINISTRA</b>: passa all\'ultimo sibling<br><b>TRASCINAMENTO VERSO DESTRA</b>: passa al primo sibling<br><br><b><img src="./images/house.png">: torna alla pagine dei progetti<br><img src="./images/sitemap_color.png">: torna alla mindmap view<br><img src="./images/slide.png">: modifica la slide<br><img src="./images/help.png">: apre il menù di help</font>', function () {
            helpOpen = false;
        });
		}
    }
}

$(document).ready(function () {
    $('#helpPresentation').click(function () {
        presentationHelp();
    });
});

//importaScript();
function importaScript(){
	if(!DetectIphone()){
	var head  = document.getElementsByTagName('head')[0];
	var script = document.createElement('meta');
	script.setAttribute("name", "viewport");
	script.setAttribute("content","width=device-width, minimum-scale=1.0, maximum-scale=1.0");
	head.appendChild(script);
	}
}

//fine importa script()

//inizializzaTouch()
var soglia = 15;

var inizializzaTouch = function(event){
		scrollStartPosX=event.touches[0].pageX; //calcola la posizione di partenza sull'asse X
		scrollStartPosY=event.touches[0].pageY; //calcola la posizione di partenza sull'asse Y
}

var moveTouch = function (event){
		var orizz;
		if( Math.abs(event.touches[0].pageX - scrollStartPosX) > Math.abs(event.touches[0].pageY - scrollStartPosY))
			orizz=true;
		else
			orizz=false;
      
		if(orizz){
			padre1=false; padre2=false;
			if(event.touches[0].pageX>scrollStartPosX && Math.abs( event.touches[0].pageX - scrollStartPosX) > soglia ){
				if (currentPosition > 0 && currentPosition <= numberOfSlides - 1)//vai alla slide precedente
					{
					 if(event.touches.length==1)
					 {deltaMove = -1; crea("Vai alla slide precedente"); }
					 else
					 {deltaMove = -currentPosition; crea("Vai alla prima slide");}
					}
				} else if(event.touches[0].pageX<scrollStartPosX && Math.abs(event.touches[0].pageX - scrollStartPosX) > soglia) {
					if (currentPosition >= 0 && currentPosition < numberOfSlides - 1) { //vai alla slide successiva
					  {
						if(event.touches.length==1)
						{deltaMove = 1; crea("Vai alla slide successiva");}
						else
						{deltaMove = -currentPosition+numberOfSlides-1; crea("Vai all'ultima slide");}
					  }
				}
			}
		}
		else{
			if(event.touches[0].pageY>scrollStartPosY && Math.abs(event.touches[0].pageY - scrollStartPosY) > soglia){
				if (parent_id !== 0) {//vai alla slide padre
					{crea("Vai alla slide padre"); padre1 = true;}
				}
				else if (slideList_id !== 0) {
					{crea("Vai alla slide padre"); padre2 = true;}
				}
			}
			else if(event.touches[0].pageY<scrollStartPosY && Math.abs(event.touches[0].pageY - scrollStartPosY) > soglia){
				{crea("Annulla"); padre1 = false; padre2 = false; deltaMove=0;}
			}
		}
		scrollStartPosX=event.touches[0].pageX; //calcola la posizione di partenza sull'asse X
		scrollStartPosY=event.touches[0].pageY; //calcola la posizione di partenza sull'asse Y
		event.preventDefault(); //e blocca il comportamento di default.
}
//fine inizializzaTouch()

var spostaSlide = function(){
	if(event.touches.length>1) return;
	if ( deltaMove ) {
		goToSlide(currentPosition + deltaMove);
		deltaMove = 0;
	}
	if(padre1)
		{padre1=false; MS.App.presentation(MS.App.selected_project, parent_id);}
	if(padre2)
		{padre2=false; MS.App.presentation(MS.App.selected_project, 0);}
	scrollStartPosX=0;
	scrollStartPosY=0;
	crea("")
}

function slideTouch(){
	if(isTouchDevice()){//è un touch device NON android (nessuna gestione nativa delle scroll interne)
	for (var i = 0; i < numberOfSlides; i += 1)
		{
		var nome = 'slide'+i;
		var slide = document.getElementById(nome);
		var scrollStartPosX=0;//posizione iniziale di scrollX = 0
		var scrollStartPosY=0;//posizione iniziale di scrollY = 0
		slide.addEventListener("touchstart", inizializzaTouch, false);
		slide.addEventListener("touchmove", moveTouch, false);
		slide.addEventListener("touchend", spostaSlide, false);
		}
	}//se non è un touch device non faccio nulla
}

function crea(contenuto){
  var id = "newdiv",
      newdiv = document.getElementById(id);
  if ( !newdiv ) {
    newdiv = document.createElement("div");
    newdiv.id = id;
    newdiv.style.position = "absolute";
	newdiv.style.fontSize="15px";
	newdiv.style.color="white";
	newdiv.style.width="10%";
	newdiv.style.backgroundColor="black";
	newdiv.style.border="4px solid grey";
	newdiv.style.webkitBorderRadius="1em";
	newdiv.style.padding="10px";
	newdiv.style.borderRadius= "1em";
	newdiv.style.top="50%";
	newdiv.style.webkitTransition="opacity 0.3s linear";
	newdiv.style.textAlign="center";
    document.getElementsByTagName('body')[0].appendChild(newdiv);
  }
 if(contenuto=="Vai alla slide precedente" || contenuto=="Vai alla prima slide")
	{newdiv.style.left="0%";}
 else if(contenuto=="Vai alla slide successiva" || contenuto=="Vai all'ultima slide")
	{newdiv.style.right="0%"; newdiv.style.left="87%";}
 else if (contenuto=="Vai alla slide padre" || contenuto=="Annulla")
	{newdiv.style.left="45%";}
else if (contenuto=="Orientamento errato! Ruotare il dispostivo in modalità orizzontale per ricaricare la pagina")
	{newdiv.style.top="20%"; newdiv.style.left="10%"; newdiv.style.border="4px solid red"; newdiv.style.fontSize="30px"; newdiv.style.width="50%"; newdiv.style.height="auto";}
 if(contenuto=="")
	{newdiv.style.opacity="0";}
 else
	{newdiv.style.opacity="1";
	 newdiv.style.visibility="visible";}
  newdiv.innerHTML = contenuto;
}

//controllo orientamento device

getOrientation.LANDSCAPE = "landscape";
getOrientation.PORTRAIT = "portrait";
getOrientation.browser_ref = "UNKNOWN";

function getOrientation(){
    if ( getOrientation.browser_ref == "UNKNOWN" ) {
      getOrientation.init();
    }
    return (window.orientation % 180) == 0 ? getOrientation.browser_ref : getOrientation.flipped_state(getOrientation.browser_ref);
}
	
getOrientation.flipped_state = function(state){
  return state == getOrientation.LANDSCAPE ? getOrientation.PORTRAIT : getOrientation.LANDSCAPE;
}
getOrientation.init = function(){
  var start_ref;
  if (window.matchMedia) {
    start_ref = matchMedia("(orientation: landscape)").matches ? getOrientation.LANDSCAPE : getOrientation.PORTRAIT ;
  } else { //per i browser che non supportano la funzione matchMedia
    var orientation = document.getElementById("orientation");
    if (!orientation) {
      var orientation = document.createElement("div");
      orientation.innerHTML = 'orientation_div'
      orientation.id="orientation";
      document.body.appendChild(orientation);
    }
    var orientation_css = document.getElementById("orientation_css");
    if (!orientation_css) {
      var orientation_css = document.createElement("style");
      orientation_css.id="orientation_css";
      var css_txt = "#orientation { display: none; font-size: 10px; }";
      css_txt += "@media only screen and (orientation:landscape){#orientation {font-size: 11px;background-color:blue;}}";
      css_txt += "@media only screen and (orientation:portrait){#orientation {font-size: 14px;background-color:red;}}";
      var rules = document.createTextNode( css_txt );
      orientation_css.type = 'text/css';
      if ( orientation_css.styleSheet ) {
          orientation_css.styleSheet.cssText = rules.nodeValue;
      } else {
        orientation_css.appendChild(rules);
      }
      document.getElementsByTagName('head')[0].appendChild(orientation_css);
    }
    start_ref = getComputedStyle(orientation,null).getPropertyValue("font-size").indexOf("11px") > -1 ? getOrientation.LANDSCAPE : getOrientation.PORTRAIT;
  }
  getOrientation.browser_ref = (window.orientation % 180) == 0 ? start_ref : getOrientation.flipped_state(start_ref)
}

//fine controllo orientamento device
var reload = false;
function controllo(){
  if ( reload ) {
    window.location.reload();
  } else if(getOrientation() == getOrientation.PORTRAIT) {
    reload = true;
    crea("Orientamento errato! Ruotare il dispostivo in modalità orizzontale per ricaricare la pagina");
  }
}


function inizializzazione(){
slideTouch();
controllo();
}