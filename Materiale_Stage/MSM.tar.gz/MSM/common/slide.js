/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 1200, indent: 4 */
/*global $, MS, Controller, console, window, localStorage, jQuery, tinyMCE */

/**********Info******************************************
 * File: view.js
 * Versione: 1.0
 * Data creazione: 14/02/2011
 * Data ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * E-mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Francesca Pastorello} correzione degli errori rilevati con JsLint
 * versione: 0.2 16/02/2011 {Francesca Pastorello} aggiunta delle funzioni edita() e conferma()
 * versione: 0.1 14/02/2011 {Francesca Pastorello} creazione classe e aggiunta della funzione edit_in_place
 *
 * ********Licenza********************************************
 *
 *This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 */
var testo;
function conferma() {
    var titolo = $('#title').val(), contenuto;
	if(!isTouchDevice())
		contenuto = tinyMCE.get('introtext').getContent();
	else
		contenuto = document.getElementById("introtext").value;
    if (titolo.length > 0) {
        MS.Model.project.slide[MS.App.selected_slide].title = titolo;
    } else {
        MS.Model.project.slide[MS.App.selected_slide].title = "slide #" + MS.App.selected_slide;
    }
    MS.Controller.setSlideContent(MS.App.selected_slide, contenuto);
    MS.Model.project.slide.modified = true;
    MS.Model.project.content.modified = true;
    MS.Controller.save();
    MS.App.mindmap(-1, -1);
}

var helpOpen = false;
function slideHelp() {
    if (helpOpen === false) {
        helpOpen = true;
        MS.View.comunication.showMessage('<font size="2px"><img src="./images/house.png">: torna alla pagine dei progetti<br><img src="./images/sitemap_color.png">: ritorna alla mindmap<br><img src="./images/control_play_blue.png">: presenta la slide<br><img src="./images/help.png">: apre il menù di help</font>', function () {
            helpOpen = false;
        });
    }
}

$(document).ready( function () {
    if (MS.App.selected_project == -1) {
        MS.App.home();
    }

    MS.Controller.loadProject(MS.App.selected_project);

    if (MS.App.selected_slide == -1) {
        MS.App.mindmap(MS.App.selected_project);
    }

    function edita() {

        if(!isTouchDevice())
		{
		tinyMCE.init({

            // General options
            mode : "textareas",
            theme : "advanced",
            plugins : "spellchecker,style,layer,table,advhr,advimage,advlink,contextmenu,visualchars,nonbreaking,wordcount,emotions",
            convert_fonts_to_spans : true,
            font_size_style_values : "14px,20px,24px,30px,40px,55px,70px",
            // Theme options
            theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,fontselect,fontsizeselect,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo",
            theme_advanced_buttons2 : "link,unlink,image,code,|,forecolor,backcolor,|,tablecontrols,|,charmap,emotions,insertlayer,moveforward,movebackward,absolute",
            theme_advanced_buttons3 : "",
            theme_advanced_buttons4 : "",

            theme_advanced_toolbar_location : "top",
            theme_advanced_toolbar_align : "left",
            setup : function (ed) {
                ed.onKeyUp.add(function (ed, e) {
                    if ((testo === undefined) || (testo === null)) {
                        testo = tinyMCE.get('introtext').getContent();
                    }
                    var txt = tinyMCE.activeEditor.getContent();
                    //strip the html
                    txt = txt.replace(/(<([^>]+)>)/ig, "");
                    txt = txt.replace(/ /g, "");
                    txt = txt.replace(/&nbsp;/g, " ");
                    if (txt.length > 800) {
                        tinyMCE.execCommand('mceSetContent', false, testo);
                        MS.View.comunication.showMessage("raggiunto numero massimo di caratteri inseribili");
                    } else {
                        testo = tinyMCE.get('introtext').getContent();
                    }
                });
            }
        });
		}

        $('#title').css('background', 'black');
        $('#title').val(MS.Model.project.slide[MS.App.selected_slide].title);
        $('#introtext').html(MS.Controller.getSlideContent(MS.App.selected_slide));

    }

    edita();

    $("#helpSlide").click( function () {
        slideHelp();
    });
});

