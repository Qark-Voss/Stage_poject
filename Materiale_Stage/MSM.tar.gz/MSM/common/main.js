/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global, ModelHandler, ControllerDispatcher, localStorage, window, $, jQuery */
/**********Info******************************************
 * File: main.js
 * Versione: 1.0
 * Data creazione: 15/02/2011
 * Data ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * E-mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Melania Miazzo} correzione degli errori rilevati con JsLint
 * versione: 0.1 15/02/2011 {Melania Miazzo} creazione della classe MS
 *
 * ********Licenza********************************************
 *
 *This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 */

var MS = {
    View : {},
    Model : {},
    Controller: {},
    App : {
        //TODO: preparare una funzione prompt che ricordi all'utente di salvare i cambiamenti prima di cambiare interfaccia
        presentation : function (project, slide) {
            this.savePrompt();
            if (slide === undefined) {
                slide = 0;
            }
            if (project != -1) {
                localStorage['selected_project'] = project;
            }
            if (slide != -1){
                localStorage['selected_slide'] = slide;
            }
            localStorage['previous_view'] == 'presentation';
            document.location.href = "./presentation.html";
        },
        home : function () {
            this.savePrompt();
            localStorage['selected_project'] = -1;
            localStorage['selected_slide'] = 0;
            localStorage['previous_view'] == 'home';
            delete localStorage['compacted'];
            document.location.href = "./index.html";
        },
        mindmap : function (project, slide) {
            this.savePrompt();
            if (slide === undefined) {
                slide = 0;
            }
            if (project != -1) {
                localStorage['selected_project'] = project;
            }
            if (slide != -1) {
                localStorage['selected_slide'] = slide
            };
            localStorage['previous_view'] == 'mindmap';
            document.location.href = "./mindmap.html";
        },
        slide : function (project, slide) {
            this.savePrompt();
            if (project != -1) {
                localStorage['selected_project'] = project;
            }
            if (slide === undefined) {
                document.location.href = "./mindmap.html";
            }
            localStorage['selected_slide'] = slide;
            localStorage['previous_view'] == 'slide';
            document.location.href = "./slide.html";
        },
        selected_project : (localStorage['selected_project'] === undefined ? -1 : localStorage['selected_project']),
        selected_slide : (localStorage['selected_slide'] === undefined ? -1 : localStorage['selected_slide']),
        previous_view : (localStorage['previous_view'] === undefined ? "home" : localStorage['previous_view']),
        savePrompt : function () {
            if (MS.Model.project !== null && (MS.Model.project.slide.modified === true || MS.Model.project.slideList.modified === true || MS.Model.project.content.modified === true)) {
                if (confirm("Sono presenti modifiche non salvate!\n\n Premendo ok verranno salvate, con cancel verranno scartate")) {
                    MS.Controller.save();
                }
            } else {
                return true;
            }
        }
    }
};

MS.Model = new ModelHandler();
MS.Controller = new ControllerDispatcher(MS.Model);

if (!MS.Model.loadUser()) {
    MS.Controller.newUser();
    console.log("new user");
}
if (typeof jQuery !== 'undefined') {
    $(window).unload( function () {
        MS.App.savePrompt();
    });
}

//controllo touch device
function isTouchDevice(){
	try{
		document.createEvent("TouchEvent");//test per touch device
		return true;
	}catch(e){
		return false;
	}
}
//fine controllo touch device

//controlli sui dispositivi
function DetectAndroid(){
var uagent = navigator.userAgent.toLowerCase();
var deviceAndroid = "android";
	   if (uagent.search(deviceAndroid) > -1)
		  return true;
	   else
		  return false;
}

function DetectIphone(){
var uagent = navigator.userAgent.toLowerCase();
var deviceIphone = "iphone";
   if (uagent.search(deviceIphone) > -1)
      return true;
   else
      return false;
}