/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global $,MS, LocalStorage */

/**********Info******************************************
 * File: mindmap.js
 * Versione: 1.0
 * Data creazione: 15/02/2011
 * Data ultima modifica: 28/02/2011
 * 
 * Gruppo: IronMad Project
 * E-mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Melania Miazzo} correzione degli errori rilevati con JsLint
 * versione: 0.2 19/02/2011 {Melania Miazzo} aggiunta della funzione mindmapHelp()
 * versione: 0.1 15/02/2011 {Melania Miazzo} creazione classe e aggiunta della funzione edit_in_place
 * 
 * ********Licenza********************************************
 * 
 *This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 */
 
if (MS.App.selected_project == -1) {
    MS.App.home();
}

var helpOpen = false;

function mindmapHelp() {
    if (helpOpen === false) {
        helpOpen = true;
		if(!isTouchDevice())
		{
        MS.View.comunication.showMessage('<font size="2px"><b>CTRL SU | </b><img src = "./images/upmini.png" />: scorre la minmap verso su<br><b>CTRL GIU\' | </b><img src="./images/downmini.png" />: scorre la mindmap verso giù<br><b>CTRL SINISTRA | </b><img src="./images/leftmini.png" />: scorre la mindmap verso sinistra<br><b>CTRL DESTRA | </b><img src="./images/rightmini.png" />: scorre la mindmap verso destra<br><b>CTRL + | mouserollup | </b><img src="./images/zoominmini.png" />: zoom in<br><b>CTRL - | mouserolldown | </b><img src="./images/zoomoutmini.png" />: zoom out<br><b>CTRL + CLICK</b>: aggiunge un sibling alla slide cliccata<br><b>SHIFT + CLICK</b>: aggiunge un child alla slide cliccata<br><br><img src="./images/house.png">: torna alla pagine dei progetti<br><img src="./images/control_play_blue.png">: avvia la presentazione partendo dalla prima slide<br><img src="./images/disk.png">: salva il progetto<br><img src="./images/callmap.png">: apre il menù di navigazione della mindmap<br><img src="./images/help.png">: apre il menù di help</font>', function () {
            helpOpen = false;
        });
		}
		else{
		MS.View.comunication.showMessage('<font size="2px"><b>Pan</b>: sposta la mindmap nella direzione del trascinamento. In alternativa: <br><img src = "./images/upmini.png" />: scorre la minmap verso su<br><img src="./images/downmini.png" />: scorre la mindmap verso giù<br><img src="./images/leftmini.png" />: scorre la mindmap verso sinistra<br><img src="./images/rightmini.png" />: scorre la mindmap verso destra<br><b>Pinch | </b><img src="./images/zoominmini.png" />: zoom in<br><b>Reverse-Pinch | </b><img src="./images/zoomoutmini.png" />: zoom out<br><br><img src="./images/house.png">: torna alla pagine dei progetti<br><img src="./images/control_play_blue.png">: avvia la presentazione partendo dalla prima slide<br><img src="./images/disk.png">: salva il progetto<br><img src="./images/callmap.png">: apre il menù di navigazione della mindmap<br><img src="./images/help.png">: apre il menù di help</font>', function () {
            helpOpen = false;
        });
		}
    }
}

$(document).ready(function () {

    MS.Controller.loadProject(MS.App.selected_project);

    MS.View.ProjectMenu.loadMenuInfo();

    MS.View.graphic.refresh();

    $(document).keydown(function (e) {
        if (e.which == 187 && e.ctrlKey === true) {
            MS.View.zpd.zoomIn();
            return false;
        } else if (e.which == 189 && e.ctrlKey === true) {
            MS.View.zpd.zoomOut();
            return false;
        } else if (e.which == 37 && e.ctrlKey === true) {
            MS.View.zpd.moveLeft();
            return false;
        } else if (e.which == 38 && e.ctrlKey === true) {
            MS.View.zpd.moveUp();
            return false;
        } else if (e.which == 39 && e.ctrlKey === true) {
            MS.View.zpd.moveRight();
            return false;
        } else if (e.which == 40 && e.ctrlKey === true) {
            MS.View.zpd.moveDown();
            return false;
        } else if (e.which == 83 && e.ctrlKey === true) {
            MS.Controller.save();
            return false;
        }
    });
    $(".edit_in_place").editInPlace({
        callback: function (idOfEditor, enteredText, orinalHTMLContent, settingsParams, animationCallbacks) {
            MS.View.ProjectMenu.saveMenuInfo();
            return enteredText;
        }
    });
    $("#helpMindmap").click(function () {
        mindmapHelp();
    });
});



