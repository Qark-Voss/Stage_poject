/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 1200, indent: 4 */
/*global MS, console, localStorage, $ */

function RemoteConnector() {
    this.packed_project = null;
    this.exportProject = function (project_id) {
        var i,
        possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
        password = "";
        for (i = 0; i < 8; i += 1) {
            password += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        if (MS.Model.project && MS.Model.project.id == project_id) {
            MS.Controller.save();
        } else {
            MS.Model.loadProject(project_id);
        }
        this.packed_project = {};
        this.packed_project.p_data = MS.Model.project;
        this.packed_project.p_info = MS.Model.user.projects[project_id];
        delete this.packed_project.p_data.id;
        delete this.packed_project.p_info.id;

        console.log("Exporting started");
        $.post("./export.php", {'project' : JSON.stringify(this.packed_project), 'password' : password}, function (data) {
            console.log("Project exported");
            if (data.match("^inserted")) {
                var index_of = data.indexOf('|'),
                id = data.substring(8, index_of),
                pwd = data.substr(index_of + 1);
                console.log("http://impslide.sourceforge.net/import.php?p=" + pwd + id);
            } else {
                console.log("error: "+data);
            }
        });
    };
    this.importProject = function (project_data) {
        var next_id = MS.Model.user.projects.next_id;
        MS.Model.user.projects.next_id += 1;
        project_data.p_data.slide.modified = true;
        project_data.p_data.slideList.modified = true;
        project_data.p_data.content.modified = true;
        project_data.p_info.id = next_id;
        project_data.p_data.id = next_id;
        MS.Model.user.projects[next_id] = project_data.p_info;
        MS.Model.project = project_data.p_data;
        MS.Controller.save();
    };
}

MS.remote = new RemoteConnector();
