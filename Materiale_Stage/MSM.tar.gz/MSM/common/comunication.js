/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global console */

/**********Info******************************************
 * File: comunication.js
 * Versione: 1.0
 * Data creazione: 15/02/2011
 * Data ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * E-mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Marco Castaldini} correzione degli errori rilevati con JsLint
 * versione: 0.1 15/02/2011 {Marco Castaldini} aggiunta delle funzioni fail(), error() e log()
 *
 * ********Licenza********************************************
 *
 *This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 */

var ERR = {
    base: "[E00] Storm, Earth and Fire, heed my call.",
    SM_not_load : "[E01] SlideManager non è ancora stato inizializzato.",
    SLM_not_load: "[E02] SlideList manager non è ancora stato inizializzato.",
    CM_not_load: "[E03] Content manager non è ancora stato inizializzato.",
    slide_not_found : "[E04] Slide not found.",
    json_invalid_parse: "[E05] Parsed string is not a json file.",
    user_not_loaded : "[E06] User not loaded.",
    storage_key_not_found : "[E07] Storage key not found.",
    json_invalid_serialization: "[E08] Provided object is not serializable. (cyclic structure?).",
    unsaved_slide : "[E09] Unsaved Slide.",
    unsaved_slideList : "[E10] Unsaved SlideList.",
    unsaved_content : "[E11] Unsaved Content.",
    project_not_loaded : "[E12] Project not loaded.",
    storageInterface_not_implemented : "[E13] L'oggetto persistence non implementa correttamente l'interfaccia PersistenceInterface."
};
var MEX = {
    base: "[M00] Storm, Earth and Fire, heed my call.",
    //first_login: "[M01] Benvenuto, questo è il tuo primo login.",
    delete_slide_0: "<code>[M01]</code> Non è possibile eliminare la prima slide del progetto.",
    choose_destination: "<code>[M02]</code> Scegli la posizione in cui spostare la slide.",
    unable_to_move_branch : "[M03] Impossibile spostare il ramo in questa posizione.",
    unable_to_move_slide : "[M04] Impossibile spostare la slide in questa posizione.",
    unable_to_move_first_slide : "[M05] Impossibile spostare la prima slide del progetto.",
    slide_max_child : "[M06] Impossibile aggiungere figli alla slide selezionata, numero massimo raggiunto.",
    ask_delete_slide : "[M07] Si vuole eliminare la\nslide ed i suoi figli?",
    confirm_delete_project : "[M08] Eliminare il progetto?"
};

function error(type) {
    if (window.console != undefined && window.console.error != undefined) {
        console.error(type);
    }
}

function fail(type) {
    if (window.console != undefined && window.console.error != undefined) {
        console.error(type);
    }
}

if (window.console == undefined) {
    console = {
        log: function () {
        },
        error : function () {
        }
    };
}

