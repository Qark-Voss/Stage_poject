/*jslint onevar: true, undef: true, newcap: true, nomen: true, regexp: true, plusplus: true, bitwise: true, devel: true, maxerr: 50, indent: 4 */
/*global $, MS, LocalStorage, window */
/**********Info******************************************
 * File: landing.js
 * Versione: 1.0
 * Data creazione: 15/02/2011
 * Data ultima modifica: 28/02/2011
 *
 * Gruppo: IronMad Project
 * E-mail: ironmadproject@gmail.com
 * Progetto: MindSlide
 *
 * ********ChangeLog*************************************
 * versione: 1.0 28/02/2011 {Deborah Rizzi} correzione degli errori rilevati con JsLint
 * versione: 0.2 17/02/2011 {Deborah Rizzi} aggiunta funzione edit_in_place()
 * versione: 0.1 15/02/2011 {Deborah Rizzi} creazione classe e aggiunta delle funzioni edit() e view()
 *
 * ********Licenza********************************************
 *
 *This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 */

function edit(id) {
    MS.App.mindmap(id);
}

function view(id) {
    MS.App.presentation(id);
}

function deletePro(id) {
    if (confirm(MEX.confirm_delete_project)) {
        MS.Controller.deleteProject(id);
        MS.App.home();
    }
}

$(document).ready( function () {

    $('#name').html(MS.Model.user.name != null && $.trim(MS.Model.user.name).length > 0 ? MS.Model.user.name : 'Inserisci Nome');
    $('#surname').html(MS.Model.user.surname != null && $.trim(MS.Model.user.surname).length > 0 ? MS.Model.user.surname : 'Inserisci Cognome');

    var project_list = MS.Controller.getProjectList(),
    key;

    for (key = project_list.length - 1; key >= 0 ; key -= 1) {
        $('#posts-list').append('<li><article class="hentry"><header><h2 class="entry-title"><a href="#" onclick="event.preventDefault();view('+project_list[key][0]+')">' + project_list[key][1].replace(" [click to modify]", "") + ' @ ' + project_list[key][2].replace(" [click to modify]", "")  + '</a></h2></header>'+
        '<footer class="post-info">'+
        '<a class="button minibutton" onclick="edit(' + project_list[key][0] + ');" ><span><span class="icon" id="mindMap"></span>Modifica</span></a>'+
        '<a class="button minibutton" onclick="view(' + project_list[key][0] + ');" ><span><span class="icon" id="presentation"></span>Presenta</span></a>'+
        '<a class="button minibutton"  onclick="deletePro(' + project_list[key][0] + ')";><span><span class="icon" id="delete"></span>Elimina</span></a></footer><div class="entry-content"><p>'+ project_list[key][3].replace(" [click to modify]", "") +'</p></div><!-- /.entry-content --></article></li>');
    }

    $('#new_project').click( function () {
        MS.Controller.newProject();
        MS.Controller.save();
        window.location.reload();
    });
    
    
});
$(".edit_in_place").editInPlace({
    callback: function (idOfEditor, enteredText, orinalHTMLContent, settingsParams, animationCallbacks) {
        MS.Model.user.name = $('#name').html();
        MS.Model.user.surname = $('#surname').html();
        MS.Model.saveUser();
        return enteredText;
    }
});