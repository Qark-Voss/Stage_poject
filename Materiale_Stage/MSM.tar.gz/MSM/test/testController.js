module("Controller's test");
	
	function getNumChild(slide_id){
    	if(MS.Model.project.slide[slide_id]===undefined){
            console.log("slide "+slide_id+ " undefined");
            return false;
        }
    	return MS.Model.project.slide[slide_id].child.length;    
    }
	function getNumSibling(slidelist_id){
	    if(MS.Model.project.slideList[slidelist_id]===undefined){
	        console.log("slideList "+slidelist_id+ " undefined");
	        return false;
	    }
    	return MS.Model.project.slideList[slidelist_id].elements.length;
	}
	
test("testing add children and siblings",function(){
	MS.Controller.newUser();

	expect(24);
	
	// la slidelist zero ora ha una slide con indice 0; la slide 0 ha zero figli 
	equal(getNumSibling(0),1,"slide 0 has one sibling"); 
	equal(getNumChild(0),0,"slide 0 has no child");
	
	// aggiungo un fratello alla slidelist 0 
	MS.Controller.addSibling(0);
	// la slidelist zero ora ha due slide sorelle (slide con indice 0 e slide con indice 1)
	equal(getNumSibling(0),2,"slidelist 0 has two siblings"); 
	
	// aggiungo un figlio alla slide 0 ->  creo una nuova slidelist con indice 1
	// la slidelist 0 ha due slide e la slidelist 1 ha una slide
	// la slidelist uno ha una slide con indice 2 che ha zero figli
	MS.Controller.addChild(0);
	equal(getNumSibling(0),2,"slidelist 0 has one siblings");
	equal(getNumSibling(1),1,"slidelist 1 has one siblings");
	
	// la slide con indice zero ha un figlio
	equal(getNumChild(0),1,"slide 0 has one child");
	// la slide con indice uno ha zero figli
	equal(getNumChild(1),0,"slide 1 has no child");
	// la slide con indice due ha zero figli
	equal(getNumChild(2),0,"slide 2 has no child");
	
	// aggiungo un secondo figlio alla slide 0 -> creo una nuova slidelist con indice 2
	// la slidelist 0 ha due slide, la slidelist 1 ha una slide e la slidelist 2 ha una slide
	// la slidelist due ha una slide con indice tre che ha zero figli
	MS.Controller.addChild(0);
	equal(getNumSibling(0),2,"slidelist 0 has two siblings");
	equal(getNumSibling(1),1,"slidelist 1 has one siblings");
	equal(getNumSibling(2),1,"slidelist 2 has one siblings");

	// la slide con indice zero ha due figlio
	equal(getNumChild(0),2,"slide 0 has two children");
	// la slide con indice uno ha zero figli
	equal(getNumChild(1),0,"slide 1 has no child");
	// la slide con indice due ha zero figli
	equal(getNumChild(2),0,"slide 2 has no child");
	// la slide con indice tre ha zero figli
	equal(getNumChild(3),0,"slide 3 has 0 children");
	
	// aggiungo un fratello alla slide 2 della slidelist 1
	// nella stessa slidelist uno ci sono due slide (slide con indice 1, slide con indice 4)
	// la slide sorella ha indice 4 e ha zero figli
	MS.Controller.addSibling(2);
	
	//la slidelist 1 ha 2 figli
	equal(getNumSibling(1),2,"slidelist 1 has two siblings");
	// la slide con indice 2 ha zero figli
	equal(getNumChild(2),0,"slide 2 has no child");
	// la slide con indice 4 ha zero figli	
	equal(getNumChild(4),0,"slide 1 has no child");
    
	// aggiungo un figlio alla slide con indice 2 -> creo una nuova slidelist con indice 3
	// la slidelist tre ha una slide con indice 5 che ha zero figli
	MS.Controller.addChild(2);
	
	equal(getNumSibling(0),2,"slidelist 0 has two siblings");
	equal(getNumSibling(1),2,"slidelist 1 has two siblings");
	equal(getNumSibling(2),1,"slidelist 2 has one sibling");
	equal(getNumSibling(3),1,"slidelist 3 has one sibling");
	
	equal(getNumChild(2),1,"slide 2 has one child");
	equal(getNumChild(5),0,"slide 5 has no child");

	MS.Controller.save();
});


test("testing delete children and siblings",function(){
	MS.Controller.loadProject(0);

	expect(16);
	
	// elimino la slide con indice 5, figlia della slide uno
	// RISULTATO: la slide due non deve avere slide figlie	
	MS.Controller.deleteSlide(5);
	equal(getNumChild(2),0,"slide 2 has no child");
	
	// elimino la slide con indice 2, figlia della slide zero
	// RISULTATO: la slide zero deve avere due figli: la slide con indice 3 e 
	// la slide con indice 4 (che era sibling->sorella della slide 2 eliminata)
	// RISULTATO: la slidelist uno deve avere un solo sibling
	MS.Controller.deleteSlide(2);
	equal(getNumChild(0),2,"slide 0 has two child");
	equal(getNumSibling(1),1,"slidelist 1 has one sibling");
	
	// viene creata la slide con indice 6 -> la slide zero ha due figli (la slide con indice 3
	// e la slide con indice 4 + la sorella con indice 6)
	MS.Controller.addSibling(4);
	equal(getNumSibling(1),2,"slidelist 1 has two siblings");
	equal(getNumChild(6),0,"slide 6 has no child");
	
	// aggiungo un figlio alla slide 4
	// creazione slidelist 4 (la slidelist 3 era stata creata per la slide 3 poi eliminata) 
	// con slide con indice 6 (è la sesta finora creata)
	MS.Controller.addChild(4);
	equal(getNumSibling(4),1,"slidelist 4 has one sibling");
	equal(getNumSibling(1),2,"slidelist 1 has two siblings");
	equal(getNumChild(7),0,"slide 7 has no child");
	equal(getNumChild(4),1,"slide 4 has one child");
	equal(getNumChild(0),2,"slide 0 has two children");
	
	// elimino la slide 4 e la slide sua figlia 7
	MS.Controller.deleteSlide(4);
	// RISULTATO: la slide zero deve avere due figli: la slide con indice 3 e 
	// la slide con indice 6 (che era sibling->sorella della slide 4 eliminata)
	equal(getNumSibling(1),1,"slidelist 1 has one sibling");
	equal(getNumChild(0),2,"slide 0 has two children");
	equal(getNumChild(6),0,"slide 6 has no children");
	
	MS.Controller.deleteSlide(6);
	// RISULTATO: la slide 0 deve avere un solo figlio ossia la slide 3 e basta
	equal(getNumSibling(0),2,"slidelist 0 has two siblings");
	equal(getNumSibling(2),1,"slidelist 2 has one sibling");
	equal(getNumChild(0),1,"slide 0 has one child");

	MS.Controller.save();
});


test("testing move slide",function(){
	MS.Controller.loadProject(0);
	
	expect(21);
	
	// controllo dati input progetto corrente
	equal(getNumSibling(0),2,"slidelist 0 has two siblings");
	equal(getNumSibling(2),1,"slidelist 2 has one sibling");
	
	equal(getNumChild(0),1,"slide 0 has one child");
	equal(getNumChild(1),0,"slide 1 has no child");
	equal(getNumChild(3),0,"slide 3 has no child");
	
	// sposto la slide con indice 1 (sorella della slide 0 e appartenente 
	// alla slidelist zero) come figlia della slide con indice 3
	MS.Controller.moveSlideAsChild(1,3);

	// controllo dati output
	equal(getNumSibling(0),1,"slidelist 0 has one sibling");
	equal(getNumSibling(2),1,"slidelist 2 has one siblingd");
	equal(getNumSibling(5),1,"slidelist 5 has one sibling");
	
	equal(getNumChild(0),1,"slide 0 has one child");
	equal(getNumChild(3),1,"slide 3 has one child");
	equal(getNumChild(1),0,"slide 1 has no child");
	
	MS.Controller.save();
	
	// aggiungo una slide sorella alla slide con indice 3
	// viene creata una slide con indice 8
	MS.Controller.addSibling(3);
	// aggiungo una slide sorella alla slide con indice 8
	// viene creata una slide con indice 9
	MS.Controller.addSibling(8);
	// aggiungo un figlio alla slide 8 -> creo slide con indice 10
	// creazione slidelist sei
	MS.Controller.addChild(8);
	
	// controllo dati input progetto corrente con modifiche effettuate
	equal(getNumSibling(0),1,"slidelist 0 has one sibling");
	equal(getNumSibling(2),3,"slidelist 2 has three siblings");
	equal(getNumSibling(5),1,"slidelist 5 has one sibling");
	equal(getNumSibling(6),1,"slidelist 6 has one sibling");
	
	equal(getNumChild(3),1,"slide 3 has one child");
	equal(getNumChild(8),1,"slide 8 has one child");
	equal(getNumChild(9),0,"slide 9 has no child");
	
	// sposto la slide con indice 8 (appartenente alla slidelist due)
	// come slide sorella della slide con inice zero appartenenete alla slidelist zero
	MS.Controller.moveSlideAsSibling(8,0);
	
	// controllo dati output
	equal(getNumSibling(0),2,"slidelist 0 has two siblings");
	equal(getNumSibling(2),2,"slidelist 2 has two siblings");
	equal(getNumSibling(5),1,"slidelist 5 has one sibling");
	
	MS.Controller.save();
});

test("testing move branch",function(){
	MS.Controller.loadProject(0);
	
	expect(20);
	
	// controllo dati input progetto corrente
	equal(getNumSibling(0),2,"slidelist 0 has two siblings");
	equal(getNumSibling(2),2,"slidelist 2 has two siblings");
	equal(getNumSibling(5),1,"slidelist 5 has one sibling");
	
	equal(getNumChild(0),1,"slide 0 has one child");
    equal(getNumChild(8),1,"slide 8 has one child");
    equal(getNumChild(10),0,"slide 10 has no child");
    equal(getNumChild(3),1,"slide 3 has one child");
    equal(getNumChild(9),0,"slide 9 has no child");
    equal(getNumChild(1),0,"slide 1 has no child");

	// aggiungo una slide sorella alla slide con indice 8
	// viene creata una slide con indice 11
	MS.Controller.addSibling(8);
	// aggiungo una slide sorella alla slide con indice 11
	// viene creata una slide con indice 12
	MS.Controller.addSibling(11);
	// controllo dati input progetto corrente con modifiche effettuate
	equal(getNumSibling(0),4,"slidelist 0 has four siblings");
	
	MS.Controller.moveBranchAsSibling(8, 1);
    
	// controllo dati output	
	equal(getNumSibling(0),1,"slidelist 0 has one sibling");
	equal(getNumSibling(2),2,"slidelist 2 has two siblings");
	equal(getNumSibling(5),4,"slidelist 5 has four siblings");
	
	equal(getNumChild(8),1,"slide 8 has one child");
    equal(getNumChild(11),0,"slide 11 has no child");
    equal(getNumChild(12),0,"slide 12 has no child");


	MS.Controller.moveBranchAsChild(11,9);

	equal(getNumSibling(2),2,"slidelist 2 has two siblings");
	equal(getNumSibling(5),2,"slidelist 5 has two siblings");
	equal(getNumSibling(7),2,"slidelist 7 has two siblings");
	
	equal(getNumChild(9),1,"slide 9 has one child");
		
	MS.Controller.save();

});

test("isPreviousOf",function(){
	MS.Controller.loadProject(0);
	
	expect(3);
	equal(MS.Controller.isPreviousOf(3, 9),true,"slide 3 is previous than slide 9");
	equal(MS.Controller.isPreviousOf(1, 10),true,"slide 1 is previous than slide 10");
	equal(MS.Controller.isPreviousOf(0, 12),true,"slide 0 is previous than slide 12");
});

test("isParentOf",function(){
	MS.Controller.loadProject(0);
	
	expect(4);
	equal(MS.Controller.isParentOf(0, 3),true,"slide 0 is parent of slide 3");
	equal(MS.Controller.isParentOf(3, 8),true,"slide 3 is parent of slide 8");
	equal(MS.Controller.isParentOf(8, 10),true,"slide 8 is parent of slide 10");
	equal(MS.Controller.isParentOf(9, 12),true,"slide 9 is parent of slide 12");
});
	
	
test("testing load Project",function(){
	// ho creato un nuovo utente, e automaticamente creo il progetto 0 	
	MS.Controller.newUser();
	
	// popolo il progetto 0
	MS.Controller.addSibling(0);
	var slide3 = MS.Model.project.slide;
	// salvo il progetto 0
	MS.Controller.save();
	
	// creo il progetto 1 per l'utente corrente
	// memorizzo la key del progetto 1
	var index1=MS.Controller.newProject();
	// popolo il progetto 1
	MS.Controller.addSibling(0);
	MS.Controller.addSibling(0);	
	// ricavo alcune informazioni del progetto 1 appena creato
	var slide = MS.Model.project.slide;
	var list = MS.Model.project.slidelist;
	// salvo il progetto 1 creato e popolato
	MS.Controller.save();
	
	// creo il progetto 2 per l'utente corrente'
	var index2=MS.Controller.newProject();
	// popolo il progetto 2
	MS.Controller.addSibling(0); 
	
	// carico il progetto 1 attraverso la sua key
	MS.Controller.loadProject(index1);	
	// ricavo alcune informazioni del progetto 1 appena caricato
	var slide2 = MS.Model.project.slide;
	var list2 = MS.Model.project.slidelist;
	
	expect(2);
	
	// confronto i risultati di prima con i risultati ora ottenuti -> devono essere uguali
	deepEqual(slide,slide2,"project loaded is true");
	deepEqual(list,list2,"project loaded is true");
});

