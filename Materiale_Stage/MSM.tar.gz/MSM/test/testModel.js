module("Model's test - LocalStorageAdapter");

var pan= new LocalStorageAdapter();
var ob=5;
var project=pan.newProjectPrototype(ob);

test("saveUser and loadUser with a numerical value", function(){
		var n_obj=5;
		pan.saveUser(n_obj);
		var load=pan.loadUser();
		equal(n_obj,load,"the numerical value written is the same as that save");
});

test("saveUser and loadUser with a boolean value", function(){
		var b_obj=false;
		pan.saveUser(b_obj);
		var load=pan.loadUser();
		equal(b_obj,load,"the boolean value written is the same as that saved");
});

test("saveUser and loadUser with an array", function(){
		var a_obj=[1,2,3];
		pan.saveUser(a_obj);
		var load=pan.loadUser();
		same(a_obj,load,"the arry's values written are the same as that saved");
});

test("saveUser and loadUser with an object",function(){
		pan.saveUser(project);
		var load=pan.loadUser();
		same(project,load,"the object written is the same as that saved");
});

test("saveProject and loadProject with an object (id, slide, slidelist, content)",function(){
		pan.saveProject(project);
		var load=pan.loadProject(ob);
		same(load,project,"the object written is the same as that saved");
});
