//includo model.js
//includo controller.js
//include main.js

MS.Controller.newProject();

console.log(MS.Model);

//all'avvio di un progetto hai la slidelist 0 con 1 elemento
// e la slide 0 con 0 figli

function getNumChild(slide_id){
    return MS.Model.project.slide[slide_id].child.length;
};
function getNumSibling(slidelist_id){
    return MS.Model.project.slideList[slidelist_id].elements.length;
};

getNumSibling(0) // la prima slidelist deve avere 1 elemento

getNumChild(0) // la prima slide deve avere 0 figli

//test aggiungo slide
MS.Controller.addSibling(0); // aggiungo un sibling alla slide 0

getNumSibling(0) // la prima slidelist ora deve essere 2

//test aggiungo child
MS.Controller.addChild(0);

getNumChild(0) // il numero di figli deve essere 1


//test aggiungo child
MS.Controller.addChild(0);

getNumChild(0) // il numero di figli deve essere 2


//slide, slidelist
//    0,0
// 1,1  2,2

getNumChild(0) // 2
getNumChild(1) //0
getNumChild(2) //0
getNumSibling(0) //1
getNumSibling(1) //1
genNumSibling(2) //1

MS.Controller.addSibling(1)

//slide, slidelist
//      0,0
// 1,1-3,1  2,2
getNumChild(0) // 2
getNumChild(1) //0
getNumChild(2) //0
getNumSibling(0) //1
getNumSibling(1) //2
genNumSibling(2) //1

MS.Controller.addChild(2)

//slide, slidelist
//      0,0
// 1,1-3,1  2,2
//          4,3
getNumChild(0) // 2
getNumChild(1) //0
getNumChild(2) //1
getNumSibling(0) //1
getNumSibling(1) //2
genNumSibling(2) //1

MS.Controller.addChild(2)


//slide, slidelist
//         0,0
// 1,1-3,1      2,2
//           4,3   5,4
getNumChild(0) // 2
getNumChild(1) //0
getNumChild(2) //1
getNumSibling(0) //1
getNumSibling(1) //2
genNumSibling(2) //2





