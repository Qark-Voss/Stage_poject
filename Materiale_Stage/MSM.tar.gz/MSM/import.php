<?php
    $landing = file_get_contents('./index.html');
    $index = strpos($landing, '</body>');
    echo substr($landing, 0, $index);

    if (isset($_GET['p']) && strlen($_GET['p']) > 8){
        $id = substr($_GET['p'], 8);
        $pwd = md5(substr($_GET['p'], 0, 8));
        
        include('./r_connect.php');
        $result = mysql_query("SELECT data, time 
FROM  `presentation` 
WHERE  `id` = $id
AND  `password` =  '$pwd'");
        if ($result && mysql_num_rows($result) == 1){
            $row = mysql_fetch_row($result);
            $project_data = $row[0];
            
            
        ?>
            <script>
                $(document).ready(function(){
                    MS.remote.importProject(<?php echo $project_data;  ?>);
                    MS.App.home();
                });
            </script>


<?php
            
                                   
       }        
    }
    echo substr($landing,$index);
?>
